# bandframework examples
This contains example scripts and files for illustrating the BAND framework.  
They should be placed in a folder in the directory examples with a subdirectory
name that generally describes the example and the code.
