# bandframework software
This contains the core software for the bandframework.  Note that one should
read bandframework/resources/sdk/bandsdk before attempting to contribute to
this branch.
