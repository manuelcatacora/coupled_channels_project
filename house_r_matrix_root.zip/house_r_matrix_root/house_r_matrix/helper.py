from jax_class_solver import Multi_Energy_Solver
import jax.numpy as jnp
import jax
from spin_projections import Spin_projections_padded
import matplotlib.pyplot as plt
from cc_couplings import CC_Couplings
from rmatrix import Rmatrix_free
from cc_constants import CC_Constants
from cc_asymptotics import CC_Asymptotics
from radial_interactions import woods_saxon_potential, woods_saxon_deformed_interaction
import time


nbasis = 30
n_int = 2
a = 40.0 #channel radius
angles =jnp.linspace(0.0, jnp.pi, 181)
E_lab_arr = [ 12.0, 14.0, 16.0, 18.0, 20.0, 22.0, 24.0, 26.0, 28.0, 30.0]
mass_t = 12.0
mass_p = 1.0
I_states = [0.0,2.0]
E_states = [0.0, 4.4398]
J_tot_max = 10.0



Hp_multi = {}
Hpp_multi = {}
Hm_multi = {}
Hmp_multi = {}
couplings_multi = {}
free_matrix_multi = {}
spin_proj_multi = {}
sqrt_k_multi = {}
sqrt_k_in_multi = {}
E_multi = {}
l_multi = {}
k_multi = {}
k_incoming = []
interaction_couplings_multi = {}
free_matrix_multi = {}

rmatrix_free_class = Rmatrix_free(nbasis)
spin_proj_class = Spin_projections_padded(angles)
couplings_class = CC_Couplings(mass_t, mass_p, E_states, I_states, 1.0, 1.0, J_tot_max)
b_arr = rmatrix_free_class.precompute_boundaries(a)


for E_lab in E_lab_arr:
    
    constants_class = CC_Constants(mass_t, mass_p, E_lab, E_states)
    hbar_2mu = constants_class.h2_mass


    quantum_numbers_dict = couplings_class.batched_dict
    
    
    E_dict, l_dict, k_dict, keys = couplings_class.generate_energy_centrifugal_mom_batched(E_lab) #passs the energy of the system
    sqrt_k_dic, sqrt_k_inv_dic = CC_Asymptotics.generate_sqrt_mom_batched(k_dict, keys)
    couplings_dict, keys = couplings_class.generate_couplings_batched(2.0) #pass the order of the deformation
    Hp_dic, Hpp_dic, Hm_dic, Hmp_dic = CC_Asymptotics.generate_bessel_batched(a, l_dict, k_dict, keys)
    spin_proj_batched, _ = spin_proj_class.precompute_spin_projections_padded(quantum_numbers_dict, keys)

    k_0 = constants_class.k()[0]
    k_incoming.append(k_0)
    incoming_index =0

    for key in keys:
        # Initialize empty list for new key if not seen before
        if key not in Hp_multi:
            Hp_multi[key] = []
            Hpp_multi[key] = []
            Hm_multi[key] = []
            Hmp_multi[key] = []
            couplings_multi[key] = []
            free_matrix_multi[key] = []
            spin_proj_multi[key] = []
            sqrt_k_multi[key] = []
            sqrt_k_in_multi[key] = []
            interaction_couplings_multi[key] = []
            E_multi[key] = []
            l_multi[key] = []
            k_multi[key] = []

        # Append new data
        Hp_multi[key].append(Hp_dic[key])
        Hpp_multi[key].append(Hpp_dic[key])
        Hm_multi[key].append(Hm_dic[key])
        Hmp_multi[key].append(Hmp_dic[key])
        couplings_multi[key].append(couplings_dict[key])
        spin_proj_multi[key].append(spin_proj_batched[key])
        sqrt_k_multi[key].append(jnp.array(sqrt_k_dic[key]))
        sqrt_k_in_multi[key].append(jnp.array(sqrt_k_inv_dic[key]))
        E_multi[key].append(jnp.array(E_dict[key]))
        l_multi[key].append(jnp.array(l_dict[key]))
        k_multi[key].append(jnp.array(k_dict[key]))
    
for key in Hp_multi:
    Hp_multi[key] = jnp.concatenate(Hp_multi[key], axis=0)  # shape: (n_E, 4, 4)
    Hpp_multi[key] = jnp.concatenate(Hpp_multi[key], axis=0)
    Hm_multi[key] = jnp.concatenate(Hm_multi[key], axis=0)
    Hmp_multi[key] = jnp.concatenate(Hmp_multi[key], axis=0)
    couplings_multi[key] = jnp.concatenate(couplings_multi[key], axis=0)
    spin_proj_multi[key] = jnp.concatenate(spin_proj_multi[key], axis=0)
    sqrt_k_multi[key] = jnp.concatenate(sqrt_k_multi[key], axis=0)
    sqrt_k_in_multi[key] = jnp.concatenate(sqrt_k_in_multi[key], axis=0)
    E_multi[key] = jnp.concatenate(E_multi[key], axis=0)
    l_multi[key] = jnp.concatenate(l_multi[key], axis=0)
    k_multi[key] = jnp.concatenate(k_multi[key], axis=0)

    
    
    
    
    
    
for key in keys:
    #extract the homogeneous shapes for testing:
    #quantum_numbers_arr = quantum_numbers_dict.get(key)
    E_arr = E_multi.get(key)
    l_arr = l_multi.get(key)
    k_arr = k_multi.get(key)
    couplings_arr = couplings_multi.get(key)
    print(E_arr.shape, couplings_arr.shape)
    batch, nch, nch = couplings_arr.shape
    diag = jnp.eye(nch, dtype=jnp.complex64)
    diag_couplings_arr = jnp.tile(diag, (batch, 1, 1))
        
        


    #generate the free matrices:
    free_matrix_arr = []
    for E, l in zip(E_arr, l_arr):
        free_matrix = rmatrix_free_class.free_matrix(a, l, E, hbar_2mu)
        free_matrix_arr.append(free_matrix)
    free_matrix_arr = jnp.array(free_matrix_arr)


    total_couplings_arr = jnp.array([couplings_arr, diag_couplings_arr])
    interaction_couplings_multi[key] = total_couplings_arr
    free_matrix_multi[key] = free_matrix_arr


jax_class_multi_energy = Multi_Energy_Solver( jnp.array(k_incoming), b_arr, Hp_multi, Hpp_multi, Hm_multi, Hmp_multi, 
                                interaction_couplings_multi, free_matrix_multi, spin_proj_multi, 
                                sqrt_k_multi, sqrt_k_in_multi, keys, hbar_2mu, a, nbasis, n_int=2, multi_energy=True, num_energies=len(E_lab_arr))


abscissa = rmatrix_free_class.kernel.quadrature.abscissa
abscissa = jnp.array(abscissa, dtype=jnp.complex64)
interaction_sph = woods_saxon_potential(a * abscissa, 77.13605, 12**(1/3)*0.9906164,  0.6949868)
interaction_def = woods_saxon_deformed_interaction(a * abscissa, 1.2, 77.13605, 12**(1/3)*0.9906164,  0.6949868)
#77.13605
interaction_sph_matrix = jnp.diag(interaction_sph)
interaction_def_matrix = jnp.diag(interaction_def)




total_interaction_multi = jnp.array([interaction_def_matrix, interaction_sph_matrix])
total_interaction_multi = jnp.array(total_interaction_multi, dtype=jnp.complex64)

_, _ = jax_class_multi_energy.cross_section_solver(total_interaction_multi)

elastic, inelastic = jax_class_multi_energy.cross_section_solver(total_interaction_multi)
elastic.block_until_ready()
inelastic.block_until_ready()


n_iter = 1000
times = []

for _ in range(n_iter):
    start = time.perf_counter()

    elastic, inelastic = jax_class_multi_energy.cross_section_solver(total_interaction_multi)
    elastic.block_until_ready()
    inelastic.block_until_ready()

    end = time.perf_counter()
    times.append(end - start)

avg_time_ms = sum(times) / len(times) * 1e3
print(f"Average time over {n_iter} iterations: {avg_time_ms:.3f} ms")