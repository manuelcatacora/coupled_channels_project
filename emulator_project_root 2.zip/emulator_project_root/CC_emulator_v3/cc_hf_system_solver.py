import numpy as np
from scipy.integrate import solve_ivp
from cc_asymptotics import CC_Asymptotics
from initial_conditions_integration import PrecomputeSafeInitialConditions
from cc_constants import CC_Constants
from cc_couplings import CC_Couplings
from radial_interactions import woods_saxon_potential, woods_saxon_deformed_interaction
from spin_projections import Spin_projections_padded

class CC_exact_solver:
    def __init__(self, mass_t, mass_p, E_lab, E_states, I_states, pi_xp, pi_xt, J_tot_max, angles = np.linspace(1e-8,np.pi,181),
                 radial_interaction_sph = woods_saxon_potential, radial_interaction_def = woods_saxon_deformed_interaction, 
                 constants_class=CC_Constants, couplings_class=CC_Couplings, r_span = (0.01, 40), r_points = 5000, channel_radius = 39.85, rtol=10e-7, atol=10e-7):
        
        self.rtol = rtol
        self.atol = atol
        self.angles= angles
        #constants of calculation class
        self.constants = constants_class(mass_t, mass_p, E_lab, E_states)
        self.I_states = I_states
        self.pi_xp = pi_xp
        self.pi_xt = pi_xt
        self.J_tot_max = J_tot_max
        
        # couplings class
        self.couplings_class = couplings_class(mass_t, mass_p, E_lab, E_states, I_states, pi_xp, pi_xt, J_tot_max, constants_class)

        #integration numerics
        self.r_span = r_span
        self.r_eval = np.linspace(*self.r_span, r_points)
        self.r_points = r_points

        #channel radius evaluation:
        self.channel_radius_idx = np.searchsorted(self.r_eval, channel_radius) #find the index of the channel radius in the r_eval array
        self.channel_radius = self.r_eval[self.channel_radius_idx]
    
        
        #interaction potentials
        self.radial_interaction_sph = radial_interaction_sph
        self.radial_interaction_def = radial_interaction_def
        
        #for the moment this is fixed for quadrupole deformations:
        self.couplings_array_pos, self.couplings_array_neg, self.quantum_num_pos, self.quantum_num_neg = self.couplings_class.couplings_J_max(2.0) #put in any Q, not tested for Q > 2.0
        self.E_array_pos, self.E_array_neg, self.l_array_pos, self.l_array_neg = self.couplings_class.energy_centrifugal_arrays()

        self.asymptotics = CC_Asymptotics(self.E_array_pos, self.E_array_neg, self.l_array_pos, self.l_array_neg, self.constants)
        self.Hp_pos, self.Hpp_pos, self.Hm_pos, self.Hmp_pos, self.Hp_neg, self.Hpp_neg, self.Hm_neg, self.Hmp_neg = self.asymptotics.CC_Bessel(self.channel_radius) #compute the asymptotic matrices for the couplings
        self.k_array_pos, self.k_array_neg, self.k_array_pos_inv, self.k_array_neg_inv = self.asymptotics.return_K_array() #compute the k arrays for the couplings
        #spin projections class 
        self.projection_class = Spin_projections_padded(self.quantum_num_pos, self.quantum_num_neg, self.angles)        
        self.spin_proj_pos, self.spin_proj_neg = self.projection_class.precompute_spin_projections() #compute the spin projections for the couplings
        
        
        #precompute the safe initial conditions for the integration over the couplings. with new function
        self.initial = PrecomputeSafeInitialConditions(self.E_array_pos, self.l_array_pos, self.E_array_neg, self.l_array_neg, self.r_span, self.constants, self.r_points,)
        self.initial_conditions_pos, self.r_new_pos, self.phi_analytical_pos, self.initial_conditions_neg, self.r_new_neg, self.phi_analytical_neg = self.initial.initial_conditions_J_max()
        

    def generating_CC_Hamiltonian(self, r, y, 
                                couplings:np.ndarray, 
                                E_array :np.ndarray, 
                                l_array: np.ndarray,
                                delta_lambda:float, 
                                *args):
        """
        Function to generate the Hamiltonian matrix for the integration of the coupled channels equations.
        """
        n_channels = couplings.shape[0]

        psi = y[:n_channels]
        dpsi = y[n_channels:]
        factor = (1/self.constants.h2_mass)

        # Compute potentials
        V_def = self.radial_interaction_def(r, delta_lambda, *args)
        V_sph = self.radial_interaction_sph(r, *args)

        #compute the off-diagonal coupling potential terms
        V_couplings = factor * couplings * V_def

        l_diag = l_array * (l_array + 1) / (r**2)
        H_0_diag = factor * (V_sph - E_array) + l_diag

        H = V_couplings + np.diag(H_0_diag)

        ddpsi =  (H @ psi)

        return np.concatenate([dpsi, ddpsi])
    
    
    def solve_CC_fundamental_matrix(self, 
                                    couplings:np.ndarray,
                                    E_array:np.ndarray,
                                    l_array:np.ndarray,
                                    delta_lambda:float,
                                    initial_conditions : np.ndarray,
                                    r_i: float,
                                    phi_analytical:np.ndarray,
                                    *args):
        """
        Function to solve the (n_channel)x(n_channel) fundamental matrix of solutions using theCC-Hamiltonian matrix.
        """
        n_channels = couplings.shape[0]
        r_f = self.r_span[1]
        r_span_new = (r_i, r_f) #we are passing through the new minimum radius from the initial condition safe class.
        idx = np.searchsorted(self.r_eval, r_i, side='left')
        r_eval_new = self.r_eval[idx:] #we are passing through the new minimum radius from the initial condition safe class.
        
        psi_matrix = np.zeros((n_channels, n_channels, self.r_points), dtype=np.complex128)
        psi_der_matrix = np.zeros((n_channels, n_channels, self.r_points), dtype=np.complex128)

        for i in range(n_channels):
            y0 = np.zeros(2 * n_channels, dtype = np.complex128)
            
            y0[n_channels + i] = initial_conditions[i][1]  # Derivative component for channel i
            y0[i] = initial_conditions[i][0]  # Initial condition for channel i of the wavefunction            
            # to make sure all the wavefunctions are evaluated at the same places, we need to define a general grid. since the Solve_IVP
            # starts integrating at some save values r_new, what we are doing here is to evaluate the wavefunctions starting
            # with the leftmost point in the grid corresponding to r_new and then evaluating at these locations, the matching to the analytical solution
            # and concatenating such that the valuation is done at the same points.
            sol = solve_ivp(self.generating_CC_Hamiltonian, r_span_new, y0, t_eval=r_eval_new, args=(couplings, E_array, l_array , delta_lambda, *args), rtol = self.rtol, atol = self.atol)

            psi_matrix[i, i, :idx] = phi_analytical[i]
            psi_matrix[:, i, idx:] = sol.y[:n_channels]
            psi_der_matrix[:, i, idx:] = sol.y[n_channels:]
            
            #lets rescale the solutions by normalizing them all up to the channel radius of the ith wavefunction

        return psi_matrix, psi_der_matrix, sol.t  # shape: (n_component, solution, radial)
    
    def solve_CC_R_matrix(self,
                          couplings: np.ndarray,
                          E_array: np.ndarray,
                          l_array: np.ndarray,
                          delta_lambda: float,
                          initial_conditions : np.ndarray,
                          r_i: float,
                          *args):
        """
        Function to solve for the R-matrix (n_channel x n_channel) through the fundamental matrix of solutions. 
        The R-matrix is defined as: R_ik = [Psi]_ij [Psi^-1]_jk
        """
        
        n_channels = couplings.shape[0]
        r_f = self.r_span[1]
        r_span_new = (r_i, r_f) #we are passing through the new minimum radius from the initial condition safe class.
        idx = np.searchsorted(self.r_eval, r_i, side='left')
        r_eval_new = self.r_eval[idx:] #we are passing through the new minimum radius from the initial condition safe class.
        
        psi_matrix = np.zeros((n_channels, n_channels, self.r_points), dtype=np.complex128)
        psi_der_matrix = np.zeros((n_channels, n_channels, self.r_points), dtype=np.complex128)
        

        for i in range(n_channels):

            y0 = np.zeros(2 * n_channels, dtype = np.complex128)
            
            y0[n_channels + i] = initial_conditions[i][1]  # Derivative component for channel i
            y0[i] = initial_conditions[i][0]  # Initial condition for channel i of the wavefunction            
            sol = solve_ivp(self.generating_CC_Hamiltonian, r_span_new, y0, t_eval=r_eval_new, args=(couplings, E_array, l_array , delta_lambda, *args), rtol = self.rtol, atol = self.atol)

            # we dont care about the analytical part of the wavefunction only the value at the channel radius with
            psi_matrix[:, i, idx:] = sol.y[:n_channels]
            psi_der_matrix[:, i, idx:] = sol.y[n_channels:]

        # Calculate the R-matrix
        a_idx =self.channel_radius_idx
        print()
        # instead of inverting the matrix, we can use np.linalg.solve to solve the linear system
        R_matrix = psi_matrix[:,:,a_idx] @ np.linalg.inv(psi_der_matrix[:,:,a_idx]) / self.r_eval[a_idx]
        #R_matrix = np.linalg.solve(psi_der_matrix[:, :, a_idx].T, psi_matrix[:, :, a_idx].T).T / self.r_eval[a_idx]

        return R_matrix



    def solve_CC_J_max(self, delta_gamma, *args):

        solutions_pos = []
        solutions_neg = []

        #der_solutions_pos = []
        #der_solutions_neg = []

        #positive parity solutions:
        for i in range(len(self.couplings_array_pos)):
            couplings = self.couplings_array_pos[i]
            E_array = self.E_array_pos[i]
            l_array = self.l_array_pos[i]
            initial_conditions = self.initial_conditions_pos[i]
            r_i = self.r_new_pos[i]
            phi_analytical = self.phi_analytical_pos[i]


            # Solve for n linearly independent solutions
            psi_matrix_pos, _, _ = self.solve_CC_fundamental_matrix(couplings, E_array, l_array, delta_gamma, initial_conditions, r_i, phi_analytical, *args)
            solutions_pos.append(psi_matrix_pos)
            #der_solutions_pos.append(psi_der_matrix_pos)

        #negative parity solutions:
        for i in range(len(self.couplings_array_neg)):
            couplings = self.couplings_array_neg[i]
            E_array = self.E_array_neg[i]
            l_array = self.l_array_neg[i]
            initial_conditions = self.initial_conditions_neg[i]
            r_i = self.r_new_neg[i]
            phi_analytical = self.phi_analytical_neg[i]

            # Solve for n linearly independent solutions
            psi_matrix_neg, _, _ = self.solve_CC_fundamental_matrix(couplings, E_array, l_array, delta_gamma, initial_conditions, r_i, phi_analytical, *args)
            solutions_neg.append(psi_matrix_neg)
            #der_solutions_neg.append(psi_der_matrix_neg)
        
        return solutions_pos, solutions_neg #der_solutions_pos, der_solutions_neg, r_vals
    


    def solve_CC_R_matrix_Jmax(self, delta_gamma, *args):
        """
        Function to solve the CC equations and return the R-matrix for each block.
        """
        R_matrix_pos = []
        R_matrix_neg = []

        #positive_parity solutions:
        for i in range(len(self.couplings_array_pos)):
            couplings = self.couplings_array_pos[i]
            E_array = self.E_array_pos[i]
            l_array = self.l_array_pos[i]
            initial_conditions = self.initial_conditions_pos[i]
            r_i = self.r_new_pos[i]

            #solve for n linearly independent solutions
            R_matrix = self.solve_CC_R_matrix(couplings, E_array, l_array, delta_gamma, initial_conditions, r_i, *args)
            #calculate the R-matrix for positive parity
            R_matrix_pos.append(R_matrix)

        for i in range(len(self.couplings_array_neg)):
            couplings = self.couplings_array_neg[i]
            E_array = self.E_array_neg[i]
            l_array = self.l_array_neg[i]
            initial_conditions = self.initial_conditions_neg[i]
            r_i = self.r_new_neg[i]

            #solve for n linearly independent solutions
            R_matrix = self.solve_CC_R_matrix(couplings, E_array, l_array, delta_gamma, initial_conditions, r_i, *args)
            #calculate the R-matrix for negative parity
            R_matrix_neg.append(R_matrix)


        return R_matrix_pos, R_matrix_neg
    

    def solve_CC_S_matrix_Jmax(self, delta_gamma, *args):
        """
        Function to solve the CC equations and return the R-matrix for each block.
        """
        S_matrix_pos = []
        S_matrix_neg = []
        a = self.r_eval[self.channel_radius_idx]

        #positive_parity solutions:
        for i in range(len(self.couplings_array_pos)):
            couplings = self.couplings_array_pos[i]
            E_array = self.E_array_pos[i]
            l_array = self.l_array_pos[i]
            initial_conditions = self.initial_conditions_pos[i]
            r_i = self.r_new_pos[i]
            h_p = self.Hp_pos[i]
            h_pp = self.Hpp_pos[i]
            h_m = self.Hm_pos[i]
            h_mp = self.Hmp_pos[i]

            #calculate the R-matrix for positive parity
            R_matrix = self.solve_CC_R_matrix(couplings, E_array, l_array, delta_gamma, initial_conditions, r_i, *args)
            Zp = h_p - R_matrix @ h_pp * a
            Zm = h_m - R_matrix @ h_mp * a
            S_matrix = np.linalg.solve(Zp, Zm)
            
            S_matrix_pos.append(S_matrix)

        for i in range(len(self.couplings_array_neg)):
            couplings = self.couplings_array_neg[i]
            E_array = self.E_array_neg[i]
            l_array = self.l_array_neg[i]
            initial_conditions = self.initial_conditions_neg[i]
            r_i = self.r_new_neg[i]
            h_p = self.Hp_neg[i]
            h_pp = self.Hpp_neg[i]
            h_m = self.Hm_neg[i]
            h_mp = self.Hmp_neg[i]

            #calculate the R-matrix for negative parity
            R_matrix = self.solve_CC_R_matrix(couplings, E_array, l_array, delta_gamma, initial_conditions, r_i, *args)
            Zp = h_p - R_matrix @ h_pp * a
            Zm = h_m - R_matrix @ h_mp * a
            S_matrix = np.linalg.solve(Zp, Zm)
            S_matrix_neg.append(S_matrix)


        return S_matrix_pos, S_matrix_neg
    
    def solve_CC_cross_section(self, delta_gamma, *args):
        """
        Function to solve the CC equations and return the R-matrix for each block.
        """
        S_matrix_pos = []
        S_matrix_neg = []
        a = self.r_eval[self.channel_radius_idx]

        #positive_parity solutions:
        for i in range(len(self.couplings_array_pos)):
            couplings = self.couplings_array_pos[i]
            E_array = self.E_array_pos[i]
            l_array = self.l_array_pos[i]
            initial_conditions = self.initial_conditions_pos[i]
            r_0 = self.r_new_pos[i]
            h_p = self.Hp_pos[i]
            h_pp = self.Hpp_pos[i]
            h_m = self.Hm_pos[i]
            h_mp = self.Hmp_pos[i]

            #calculate the R-matrix for positive parity
            R_matrix = self.solve_CC_R_matrix(couplings, E_array, l_array, delta_gamma, initial_conditions, r_0, *args)
            Zp = h_p - R_matrix @ h_pp * a
            Zm = h_m - R_matrix @ h_mp * a
            S_matrix = np.linalg.solve(Zp, Zm)
            
            S_matrix_pos.append(S_matrix)

        for i in range(len(self.couplings_array_neg)):
            couplings = self.couplings_array_neg[i]
            E_array = self.E_array_neg[i]
            l_array = self.l_array_neg[i]
            initial_conditions = self.initial_conditions_neg[i]
            r_0 = self.r_new_neg[i]
            h_p = self.Hp_neg[i]
            h_pp = self.Hpp_neg[i]
            h_m = self.Hm_neg[i]
            h_mp = self.Hmp_neg[i]

            #calculate the R-matrix for negative parity
            R_matrix = self.solve_CC_R_matrix(couplings, E_array, l_array, delta_gamma, initial_conditions, r_0, *args)
            Zp = h_p - R_matrix @ h_pp * a
            Zm = h_m - R_matrix @ h_mp * a
            S_matrix = np.linalg.solve(Zp, Zm)
            S_matrix_neg.append(S_matrix)

    def get_wavefunction_array(self, array_params):
        '''
        Function to get the wavefunction array for many parameters for the CC equations.
        '''
        solutions_pos, solutions_neg = [], []
        for param in array_params:
            pos, neg  = self.solve_CC_J_max(param[0], *param[1:]) 
            solutions_pos.append(pos)
            solutions_neg.append(neg)
        

        return solutions_pos, solutions_neg
    

    def free_solutions(self):
        """ 
        Function to solve the free solutions for each partial wave l
        """

        free_sol_array_pos = []
        for i in range(len(self.E_array_pos)):
            E_array = self.E_array_pos[i]
            n_ch = E_array.shape[0]
            l_array = self.l_array_pos[i]
            initial_conditions = self.initial_conditions_pos[i]
            r_i = self.r_new_pos[i]
            array_fill = np.zeros((n_ch, n_ch, self.r_points), dtype = np.complex128)
            phi_analytical = self.phi_analytical_pos[i]
            for j in range(len(E_array)):
                E = E_array[j]
                l = l_array[j]
                init = initial_conditions[j]
                r_span_new = (r_i, self.r_span[1])
                idx = np.searchsorted(self.r_eval, r_i, side='left')
                r_eval_new = self.r_eval[idx:] #we are passing through the new minimum radius from the initial condition safe class.
                free_sol = solve_ivp(lambda r, y: [y[1], ((l*(l+1))/r**2 - (1/self.constants.h2_mass)*E)*y[0]], r_span_new, init, t_eval=r_eval_new, rtol=self.rtol, atol=self.atol)
                array_fill[j,j,:] = np.concatenate((phi_analytical[j],free_sol.y[0]), axis = 0)
            free_sol_array_pos.append(array_fill)

        free_sol_array_neg = []
        for i in range(len(self.E_array_neg)):
            E_array = self.E_array_neg[i]
            n_ch = E_array.shape[0]
            l_array = self.l_array_neg[i]
            initial_conditions = self.initial_conditions_neg[i]
            r_i = self.r_new_neg[i]
            array_fill = np.zeros((n_ch, n_ch, self.r_points), dtype = np.complex128)
            phi_analytical = self.phi_analytical_neg[i]
            for j in range(len(E_array)):
                E = E_array[j]
                l = l_array[j]
                init = initial_conditions[j]
                r_span_new = (r_i, self.r_span[1])
                idx = np.searchsorted(self.r_eval, r_i, side='left')
                r_eval_new = self.r_eval[idx:] #we are passing through the new minimum radius from the initial condition safe class.
                free_sol = solve_ivp(lambda r, y: [y[1], ((l*(l+1))/r**2 - (1/self.constants.h2_mass)*E)*y[0]], r_span_new, init, t_eval=r_eval_new, rtol=self.rtol, atol=self.atol)
                array_fill[j,j,:] = np.concatenate((phi_analytical[j],free_sol.y[0]), axis = 0)
            free_sol_array_neg.append(array_fill)

        return free_sol_array_pos, free_sol_array_neg