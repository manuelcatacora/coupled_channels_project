import numpy as np

MAX_ARG = np.log(1 / 1e-16)  # ~36.8 to prevent overflow in exp(x)

def woods_saxon_safe(r, R, a):
    """
    Woods-Saxon shape f(r) = 1 / (1 + exp((r - R)/a))
    Safe for np.complex128 input
    """
    x = (r - R) / a
    x = np.asarray(x, dtype=np.complex128)

    V = np.zeros_like(x, dtype=np.complex128)
    mask = np.real(x) <= MAX_ARG  # safe cutoff based on real part
    V[mask] = 1.0 / (1.0 + np.exp(x[mask]))

    return V


def woods_saxon_prime_safe(r, R, a):
    """
    Derivative f'(r) = -exp(x) / [a * (1 + exp(x))^2]
    """
    x = (r - R) / a
    x = np.asarray(x, dtype=np.complex128)

    dV = np.zeros_like(x, dtype=np.complex128)
    mask = np.real(x) <= MAX_ARG
    ex = np.exp(x[mask])
    dV[mask] = -ex / (a * (1 + ex) ** 2)

    return dV


def woods_saxon_potential(r, V0, R, a):
    """
    Full Woods-Saxon potential V(r) = -V0 * f(r)
    """
    return - V0 * woods_saxon_safe(r, R, a)


def woods_saxon_prime(r, V0, R, a):
    """
    Derivative V'(r) = V0 * f'(r)
    """
    return V0 * woods_saxon_prime_safe(r, R, a)


def woods_saxon_deformed_interaction(r, delta_lambda, V0, R, a):
    """
    First-order deformed Woods-Saxon interaction:
    V_def(r) = V0 * δλ / sqrt(4π) * f'(r)
    """
    prefactor = delta_lambda / np.sqrt(4 * np.pi)
    return V0 * prefactor * woods_saxon_prime_safe(r, R, a)


