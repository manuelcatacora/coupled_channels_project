import numpy as np
from cc_constants import CC_Constants
import scipy.special as sc
from mpmath import coulombf, coulombg


from scipy.special import spherical_jn, spherical_yn

def F(r, ell, k):
    rho = k * r
    return rho * spherical_jn(int(ell), rho)

def G(r, ell, k):
    rho = k * r
    return - rho * spherical_yn(int(ell), rho)

def F_prime(r, ell, k):
    rho = k * r
    return k * (spherical_jn(int(ell), rho)) + rho * spherical_jn(int(ell), rho, derivative=True)

def G_prime(r, ell, k):
    rho = k * r
    return  - k * (spherical_yn(int(ell), rho)) + rho * spherical_yn(int(ell), rho, derivative=True)

def H_plus(r, ell, k):
    return G(r, ell, k) + 1j * F(r, ell, k)

def H_minus(r, ell, k):
    return G(r, ell, k) - 1j * F(r, ell, k)

def H_plus_prime(r, ell, k):
    return G_prime(r, ell, k) + 1j * F_prime(r, ell, k)
 
def H_minus_prime(r, ell, k):
    return G_prime(r, ell, k) - 1j* F_prime(r, ell, k)

class CC_Asymptotics:
    def __init__(
        self, 
        E_array_pos, E_array_neg, 
        l_array_pos, l_array_neg, 
        constants_class, 
    ):
        self.constants = constants_class
        self.E_array_pos = E_array_pos
        self.E_array_neg = E_array_neg
        self.l_array_pos = l_array_pos
        self.l_array_neg = l_array_neg


    def return_K_array(self):
        """
        Returns wave number arrays (k) and their inverses (1/k) for each parity block.
        Uses: E = ħ²k² / (2μ) => k = sqrt(E * 2μ / ħ²)
        Assumes E arrays are already real or complex and padded properly.
        """
        h2_inv = 1.0 / self.constants.h2_mass  # hbar² / (2μ), inverted

        def make_k_arrays(E_list):
            E_complex = [E.astype(np.complex128) for E in E_list]
            sqrt_E = [np.sqrt(h2_inv * E) for E in E_complex]
            k_diag = [np.diag(k) for k in sqrt_E]
            k_inv_diag = [np.diag(1.0 / k) for k in sqrt_E]
            return k_diag, k_inv_diag

        k_array_pos, k_array_pos_inv = make_k_arrays(self.E_array_pos)
        k_array_neg, k_array_neg_inv = make_k_arrays(self.E_array_neg)

        return k_array_pos, k_array_neg, k_array_pos_inv, k_array_neg_inv

    def CC_Bessel(self, r):
        """
        Computes the Bessel functions (H±) and their derivatives (H±') at fixed radius r
        for all coupled-channel blocks, split by parity.
        Returns:
            (Hp_pos, Hpp_pos, Hm_pos, Hmp_pos,
             Hp_neg, Hpp_neg, Hm_neg, Hmp_neg)
        Each of these is a list of diagonal matrices (np.array of shape (n_channels, n_channels))
        """
        def compute_block(E_block, l_block):
            k_block = np.sqrt(np.float64(1 / self.constants.h2_mass) * E_block.astype(np.float64))
            #print(k_block)
            #print(l_block)
            #s = k * r  # dimensionless radial variable
            Hp  = [H_plus(r, li, ki)        for li, ki in zip(l_block, k_block)]
            Hpp = [H_plus_prime(r, li, ki)  for li, ki in zip(l_block, k_block)]
            Hm  = [H_minus(r, li, ki)       for li, ki in zip(l_block, k_block)]
            Hmp = [H_minus_prime(r, li, ki) for li, ki in zip(l_block, k_block)]
            return Hp, Hpp, Hm, Hmp

        Hp_pos, Hpp_pos, Hm_pos, Hmp_pos = [], [], [], []
        Hp_neg, Hpp_neg, Hm_neg, Hmp_neg = [], [], [], []

        for E_block, l_block in zip(self.E_array_pos, self.l_array_pos):
            Hp, Hpp, Hm, Hmp = compute_block(E_block, l_block)
            Hp_pos.append(np.diag(Hp))
            Hpp_pos.append(np.diag(Hpp))
            Hm_pos.append(np.diag(Hm))
            Hmp_pos.append(np.diag(Hmp))

        for E_block, l_block in zip(self.E_array_neg, self.l_array_neg):
            Hp, Hpp, Hm, Hmp = compute_block(E_block, l_block)
            Hp_neg.append(np.diag(Hp))
            Hpp_neg.append(np.diag(Hpp))
            Hm_neg.append(np.diag(Hm))
            Hmp_neg.append(np.diag(Hmp))

        return Hp_pos, Hpp_pos, Hm_pos, Hmp_pos, Hp_neg, Hpp_neg, Hm_neg, Hmp_neg




# class CoulombAsymptotics:
#     @staticmethod
#     def F(s, l, eta):
#         """
#         Coulomb function of the first kind.
#         """
#         return np.complex128(coulombf(l, eta, s))

#     @staticmethod
#     def G(s, l, eta):
#         """
#         Coulomb function of the second kind.
#         """
#         return np.complex128(coulombg(l, eta, s))


# def H_plus(s, l, eta, asym=CoulombAsymptotics):
#     """
#     Hankel/Coulomb-Hankel function of the first kind (outgoing).
#     """
#     return asym.G(s, l, eta) + 1j * asym.F(s, l, eta)


# def H_minus(s, l, eta, asym=CoulombAsymptotics):
#     """
#     Hankel/Coulomb-Hankel function of the second kind (incoming).
#     """
#     return asym.G(s, l, eta) - 1j * asym.F(s, l, eta)

# def free_solution(s, l, eta):
#     """
#     Free solution to the radial Schrödinger equation.
#     """
#     return H_minus(s, l, eta)  - H_plus(s, l, eta) 


# def coulomb_func_deriv(func, s, l, eta):
#     """
#     Derivative of Coulomb functions F, G, and Coulomb Hankel functions H+ and H-
#     """
#     # recurrance relations from https://dlmf.nist.gov/33.4
#     # dlmf Eq. 33.4.4
#     R = np.sqrt(1 + eta**2 / (l + 1) ** 2)
#     S = (l + 1) / s + eta / (l + 1)
#     Xl = func(s, l, eta)
#     Xlp = func(s, l + 1, eta)
#     return S * Xl - R * Xlp


# def H_plus_prime(s, l, eta, asym=CoulombAsymptotics):
#     """
#     Derivative of the Hankel function (first kind) with respect to s
#     """
#     return coulomb_func_deriv(H_plus, s, l, eta)


# def H_minus_prime(s, l, eta, dx=1e-6, asym=CoulombAsymptotics):
#     """
#     Derivative of the Hankel function (second kind) with respect to s.
#     """
#     return coulomb_func_deriv(H_minus, s, l, eta)


# class CC_Asymptotics:
#     def __init__(
#         self, 
#         E_array_pos, E_array_neg, 
#         l_array_pos, l_array_neg, 
#         constants_class, 
#         eta_arr_pos=None, eta_arr_neg=None
#     ):
#         self.constants = constants_class
#         self.E_array_pos = E_array_pos
#         self.E_array_neg = E_array_neg
#         self.l_array_pos = l_array_pos
#         self.l_array_neg = l_array_neg

#         self.eta_arr_pos = eta_arr_pos if eta_arr_pos is not None else [
#             np.zeros_like(E, dtype=np.complex128) for E in E_array_pos
#         ]
#         self.eta_arr_neg = eta_arr_neg if eta_arr_neg is not None else [
#             np.zeros_like(E, dtype=np.complex128) for E in E_array_neg
#         ]

#     def return_K_array(self):
#         """
#         Returns wave number arrays (k) and their inverses (1/k) for each parity block.
#         Uses: E = ħ²k² / (2μ) => k = sqrt(E * 2μ / ħ²)
#         Assumes E arrays are already real or complex and padded properly.
#         """
#         h2_inv = 1.0 / self.constants.h2_mass  # hbar² / (2μ), inverted

#         def make_k_arrays(E_list):
#             E_complex = [E.astype(np.complex128) for E in E_list]
#             sqrt_E = [np.sqrt(h2_inv * E) for E in E_complex]
#             k_diag = [np.diag(k) for k in sqrt_E]
#             k_inv_diag = [np.diag(1.0 / k) for k in sqrt_E]
#             return k_diag, k_inv_diag

#         k_array_pos, k_array_pos_inv = make_k_arrays(self.E_array_pos)
#         k_array_neg, k_array_neg_inv = make_k_arrays(self.E_array_neg)

#         return k_array_pos, k_array_neg, k_array_pos_inv, k_array_neg_inv

#     def CC_Coulombf(self, r):
#         """
#         Computes the Coulomb-Hankel functions (H±) and their derivatives (H±') at fixed radius r
#         for all coupled-channel blocks, split by parity.
#         Returns:
#             (Hp_pos, Hpp_pos, Hm_pos, Hmp_pos,
#              Hp_neg, Hpp_neg, Hm_neg, Hmp_neg)
#         Each of these is a list of diagonal matrices (np.array of shape (n_channels, n_channels))
#         """
#         def compute_block(E_block, l_block, eta_block):
#             k = np.sqrt((1 / self.constants.h2_mass) * E_block.astype(np.complex128))
#             s = k * r  # dimensionless radial variable
#             Hp  = [H_plus(si, li, etai)        for si, li, etai in zip(s, l_block, eta_block)]
#             Hpp = [H_plus_prime(si, li, etai)  for si, li, etai in zip(s, l_block, eta_block)]
#             Hm  = [H_minus(si, li, etai)       for si, li, etai in zip(s, l_block, eta_block)]
#             Hmp = [H_minus_prime(si, li, etai) for si, li, etai in zip(s, l_block, eta_block)]
#             return Hp, Hpp, Hm, Hmp

#         Hp_pos, Hpp_pos, Hm_pos, Hmp_pos = [], [], [], []
#         Hp_neg, Hpp_neg, Hm_neg, Hmp_neg = [], [], [], []

#         for E_block, l_block, eta_block in zip(self.E_array_pos, self.l_array_pos, self.eta_arr_pos):
#             Hp, Hpp, Hm, Hmp = compute_block(E_block, l_block, eta_block)
#             Hp_pos.append(np.diag(Hp))
#             Hpp_pos.append(np.diag(Hpp))
#             Hm_pos.append(np.diag(Hm))
#             Hmp_pos.append(np.diag(Hmp))

#         for E_block, l_block, eta_block in zip(self.E_array_neg, self.l_array_neg, self.eta_arr_neg):
#             Hp, Hpp, Hm, Hmp = compute_block(E_block, l_block, eta_block)
#             Hp_neg.append(np.diag(Hp))
#             Hpp_neg.append(np.diag(Hpp))
#             Hm_neg.append(np.diag(Hm))
#             Hmp_neg.append(np.diag(Hmp))

#         return Hp_pos, Hpp_pos, Hm_pos, Hmp_pos, Hp_neg, Hpp_neg, Hm_neg, Hmp_neg