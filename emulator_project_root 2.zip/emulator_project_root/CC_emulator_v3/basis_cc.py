import findiff as FinDiff
import numpy as np
from cc_hf_system_solver import CC_exact_solver
from radial_interactions import woods_saxon_potential, woods_saxon_deformed_interaction
from cc_constants import CC_Constants
from cc_couplings import CC_Couplings

class Basis_CC(CC_exact_solver):
    def __init__(self, mass_t, mass_p, E_lab, E_states, I_states, pi_xp, pi_xt, J_tot_max, training_array_RBM, angles = np.linspace(1e-4,np.pi,180),
                 radial_interaction_sph = woods_saxon_potential, radial_interaction_def = woods_saxon_deformed_interaction, 
                 constants_class=CC_Constants, couplings_class=CC_Couplings, r_span = (0.01, 40), r_points = 5000, channel_radius = 39.85, rtol= 10e-8, atol=10e-9):
        

        
        super().__init__(mass_t, mass_p, E_lab, E_states, I_states, pi_xp, pi_xt, J_tot_max,
                         angles=angles,
                         radial_interaction_sph=radial_interaction_sph,
                         radial_interaction_def=radial_interaction_def,
                         constants_class=constants_class,
                         couplings_class=couplings_class,
                         r_span=r_span,
                         r_points=r_points,
                         channel_radius=channel_radius,
                         rtol=rtol,
                         atol=atol)
        
        self.training_array_RBM = training_array_RBM
        self.dim_RBM_train = training_array_RBM.shape[0]
        self.n_train = len(self.training_array_RBM)

        self.processed_solutions_pos, self.processed_solutions_neg = self.pre_process_solutions()
        
    def pre_process_solutions(self):
        """
        Function to pre-process the solutions for the RBM training. The solutions are re-formatted to have shape [n_samples, J, n_channels, n_channels, r_points].
        Then the free solution is subtracted from the diagonal elements of the training solutions. The diagonals correspond to waves with incoming boundary conditions.
        """
        #find the maximum number of channels in the training set to pad the solutions
        self.max_n_channels_pos = self.couplings_array_pos[-1].shape[0]
        self.max_n_channels_neg = self.couplings_array_neg[-1].shape[0]
        
        #find the dimensions of the positive and negative parity solutions (how many J's)
        self.J_dim_pos = len(self.quantum_num_pos)
        self.J_dim_neg = len(self.quantum_num_neg)

        #get the solutions for the training set
        solutions_pos_array, solutions_neg_array = self.get_wavefunction_array(self.training_array_RBM)
        free_pos_array, free_neg_array = self.free_solutions()

        #store the number of channels for each J, to recover from padding
        self.n_channels_by_J_pos = [solutions_pos_array[0][i].shape[0] for i in range(self.J_dim_pos)]
        self.n_channels_by_J_neg = [solutions_neg_array[0][i].shape[0] for i in range(self.J_dim_neg)]
        
        #initialize the padded arrays
        training_solutions_pos_padded = np.zeros((self.n_train, self.J_dim_pos, self.max_n_channels_pos, self.max_n_channels_pos, self.r_points), dtype=complex)
        training_solutions_neg_padded = np.zeros((self.n_train, self.J_dim_neg, self.max_n_channels_neg, self.max_n_channels_neg, self.r_points), dtype=complex)
        free_solution_pos_padded = np.zeros((self.J_dim_pos, self.max_n_channels_pos, self.max_n_channels_pos, self.r_points), dtype=complex)
        free_solution_neg_padded = np.zeros((self.J_dim_neg, self.max_n_channels_neg, self.max_n_channels_neg, self.r_points), dtype=complex)
        
        #pad the solutions
        for i in range(self.n_train):
            for j in range(self.J_dim_pos):
                arr = solutions_pos_array[i][j]
                n_ch = arr.shape[0]
                training_solutions_pos_padded[i,j,:n_ch,:n_ch,:] = arr
                free_solution_pos_padded[j,:n_ch,:n_ch,:] = free_pos_array[j]

            for j in range(self.J_dim_neg):
                arr = solutions_neg_array[i][j]
                n_ch = arr.shape[0]
                training_solutions_neg_padded[i,j,:n_ch,:n_ch,:] = arr
                free_solution_neg_padded[j,:n_ch,:n_ch,:] = free_neg_array[j]
        
        self.free_solutions_pos = free_solution_pos_padded
        self.free_solutions_neg = free_solution_neg_padded

        self.training_solutions_pos = training_solutions_pos_padded
        self.training_solutions_neg = training_solutions_neg_padded

        processed_arr_pos = training_solutions_pos_padded - free_solution_pos_padded
        processed_arr_neg = training_solutions_neg_padded - free_solution_neg_padded

        #return the processed arrays and the number of channels for each J
        return processed_arr_pos, processed_arr_neg
    

    def get_RBM_training_data(self, nbasis):
        """
        Function to get the RBMs using PCA.
        """
        SVD_pos = np.zeros((nbasis, self.J_dim_pos, self.max_n_channels_pos, self.max_n_channels_pos, self.r_points), dtype=complex)
        SVD_neg = np.zeros((nbasis, self.J_dim_neg, self.max_n_channels_neg, self.max_n_channels_neg, self.r_points), dtype=complex)

        SVD_D2_pos = np.zeros_like(SVD_pos)
        SVD_D1_pos = np.zeros_like(SVD_pos)

        SVD_D2_neg = np.zeros_like(SVD_neg)
        SVD_D1_neg = np.zeros_like(SVD_neg)



        for i in range(self.J_dim_pos):
            dx_new = (self.r_span[1] - self.r_new_pos[i]) / (self.r_points - 1) 
            D1 = FinDiff(1, dx_new, 1, acc=8)   # axis, dx, order, accuracy
            D2 = FinDiff(1, dx_new, 2, acc=8) 

            for j in range(self.n_channels_by_J_pos[i]):
                for k in range(self.n_channels_by_J_pos[i]):
                    waves_n_train = self.processed_solutions_pos[:,i,j,k,:]
                    U, S, Vt = np.linalg.svd(waves_n_train.T, full_matrices=False)
                    basis = U[:, :nbasis]
                    SVD_pos[:,i,j,k,:] = basis.T
                    SVD_D1_pos[:,i,j,k,:] = D1(basis.T)
                    SVD_D2_pos[:,i,j,k,:] = D2(basis.T)

        for i in range(self.J_dim_neg):
            dx_new = (self.r_span[1] - self.r_new_neg[i]) / (self.r_points - 1)
            D1 = FinDiff(1, dx_new, 1, acc=8)
            D2 = FinDiff(1, dx_new, 2, acc=8)
            for j in range(self.n_channels_by_J_neg[i]):
                for k in range(self.n_channels_by_J_neg[i]):
                    waves_n_train = self.processed_solutions_neg[:,i,j,k,:]
                    U, S, Vt = np.linalg.svd(waves_n_train.T, full_matrices=False)
                    basis = U[:, :nbasis]
                    SVD_neg[:,i,j,k,:] = basis.T
                    SVD_D1_neg[:,i,j,k,:] = D1(basis.T)
                    SVD_D2_neg[:,i,j,k,:] = D2(basis.T)

        #return the SVD matrices
        return SVD_pos, SVD_neg, SVD_D1_pos, SVD_D1_neg, SVD_D2_pos, SVD_D2_neg