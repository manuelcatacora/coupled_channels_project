import numpy as np
from typing import Sequence, Optional

def Gamow_factor(l, eta):
    r"""This returns the... Gamow factor.
    See [Wikipedia](https://en.wikipedia.org/wiki/Gamow_factor).

    Parameters:
        l (int): angular momentum
        eta (float): Sommerfeld parameter (see
            [Wikipedia](https://en.wikipedia.org/wiki/Sommerfeld_parameter))

    Returns:
        C_l (float): Gamow factor

    """
    if eta == 0.0:
        if l == 0:
            return 1
        else:
            return 1 / (2 * l + 1) * Gamow_factor(l - 1, 0)
    elif l == 0:
        return np.sqrt(2 * np.pi * eta / (np.exp(2 * np.pi * eta) - 1))
    else:
        return np.sqrt(l**2 + eta**2) / (l * (2 * l + 1)) * Gamow_factor(l - 1, eta)
    


class PrecomputeSafeInitialConditions:
    def __init__(
        self,
        E_array_pos: Sequence[np.ndarray],
        l_array_pos: Sequence[np.ndarray],
        E_array_neg: Sequence[np.ndarray],
        l_array_neg: Sequence[np.ndarray],
        r_span: tuple[float, float],
        constants_class,
        r_points: int,
        eta_arr_pos: Optional[Sequence[np.ndarray]] = None,
        eta_arr_neg: Optional[Sequence[np.ndarray]] = None,
        phi_threshold: float = 1e-17
    ):
        self.phi_threshold = phi_threshold
        self.l_array_pos = l_array_pos
        self.l_array_neg = l_array_neg
        self.E_array_pos = E_array_pos
        self.E_array_neg = E_array_neg
        self.constants = constants_class
        self.r_eval = np.linspace(r_span[0], r_span[1], r_points)
        self.r_span = r_span
        self.r_0 = r_span[0]

        # Use complex128 always
        self.eta_arr_pos = eta_arr_pos if eta_arr_pos is not None else [
            np.zeros_like(E, dtype=np.complex128) for E in E_array_pos
        ]
        self.eta_arr_neg = eta_arr_neg if eta_arr_neg is not None else [
            np.zeros_like(E, dtype=np.complex128) for E in E_array_neg
        ]

    def redefine_r_grid(self, eta_max: complex, phi_threshold: float, l_max: int, r_0: float, k_max: complex) -> float:
        """Redefines the r-grid cutoff based on threshold and Gamow tail."""
        rho_0 = r_0 * k_max
        C_l_max = Gamow_factor(l_max, eta_max)
        min_rho_0 = (phi_threshold / C_l_max) ** (1 / (l_max + 1))
        return np.real(max(rho_0, min_rho_0) / k_max)

    def initial_conditions(self, eta: np.ndarray, l: np.ndarray, r_i: float, k: np.ndarray) -> np.ndarray:
        """Vectorized computation of initial conditions at r_i."""
        rho_i = r_i * k
        C_l = np.array([Gamow_factor(li, etai) for li, etai in zip(l, eta)], dtype=np.complex128)
        phi_0 = C_l * rho_i**(l + 1)
        phi_prime_0 = C_l * (l + 1) * rho_i**l
        return np.stack([phi_0, phi_prime_0], axis=-1)

    def compute_analytical_solution(
        self, eta: np.ndarray, l: np.ndarray, r_array: np.ndarray, k: np.ndarray
    ) -> np.ndarray:
        """Vectorized analytical Gamow solution across r_array."""
        rho = np.outer(k, r_array)  # shape (n_channels, len(r_array))
        C_l = np.array([Gamow_factor(li, etai) for li, etai in zip(l, eta)], dtype=np.complex128)
        return C_l[:, None] * rho**(l[:, None] + 1)

    def _compute_initial_conditions(
        self, E_array: Sequence[np.ndarray], l_array: Sequence[np.ndarray],
        eta_array: Sequence[np.ndarray], h2_mass_inv: complex
    ):
        """Main vectorized routine to compute initial conditions and reference solutions."""
        init_list = []
        r_new_list = []
        phi_list = []

        for E, l, eta in zip(E_array, l_array, eta_array):
            l_max = np.max(l)
            eta_max = np.max(eta)
            k = np.sqrt(h2_mass_inv * E.astype(np.complex128))
            k_max = np.max(k)
            #print(l_max)
            r_new = self.redefine_r_grid(eta_max, self.phi_threshold, l_max, self.r_0, k_max)
            idx = np.searchsorted(self.r_eval, r_new, side='left')
            r_slice = self.r_eval[:idx]

            # Vectorized per J block
            init_block = self.initial_conditions(eta, l, r_new, k)  # shape (n_channels, 2)
            phi_block = self.compute_analytical_solution(eta, l, r_slice, k)  # shape (n_channels, len(r_slice))

            init_list.append(init_block)
            r_new_list.append(r_new)
            phi_list.append(phi_block)

        return init_list, r_new_list, phi_list

    def initial_conditions_J_max(self):
        """Compute initial conditions, r_cutoffs, and analytic solutions.

        Returns:
            Tuple:
                - initial_conditions (List of [n_channels x 2] arrays)
                - r_cutoff_per_J (List of floats)
                - phi_analytic (List of [n_channels x r_eval_short] arrays)
        """
        h2_mass_inv = 1 / self.constants.h2_mass
        pos_results = self._compute_initial_conditions(self.E_array_pos, self.l_array_pos, self.eta_arr_pos, h2_mass_inv)
        neg_results = self._compute_initial_conditions(self.E_array_neg, self.l_array_neg, self.eta_arr_neg, h2_mass_inv)
        return  (*pos_results, *neg_results)
