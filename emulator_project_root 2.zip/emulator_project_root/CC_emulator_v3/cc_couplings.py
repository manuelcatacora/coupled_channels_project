import numpy as np
from sympy.physics.wigner import clebsch_gordan
from sympy.physics.wigner import wigner_6j
from cc_constants import CC_Constants


def hat(a):
    """
    Normalization coefficient: sqrt(2a + 1)
    Returns np.complex128
    """
    return np.complex128(np.sqrt(2 * a + 1))


def coupling_matrix_elements(I_i, l_i, j_i, I_f, l_f, j_f, s, J, Q):
    '''
    Given the quantum numbers of one specific choice of initial and final channels calculate the coupling
    coefficient. This is the general form, for the moment l_i=j_i, s=0, l_f=j_f and both I_f, I_i must be even.
    '''
    K_f = 0  ## for I=0,2,4 only
    K_i = 0  ## for I=0,2,4 only
    coupling_initial_final = (1j**(l_i-l_f))*(-1)**(Q+J+l_i+I_f)*hat(I_i)*hat(l_i)*hat(Q) \
               * wigner_6j(l_i,I_i,J,I_f,l_f,Q).n(17) *clebsch_gordan(l_i,Q,l_f,0,0,0).n(17)\
               *clebsch_gordan(I_i,Q,I_f,K_i,0,K_f).n(17)
    
    return coupling_initial_final


class CC_Couplings:
    def __init__(self, mass_t, mass_p, E_lab, E_states, I_states, pi_xp, pi_xt, J_tot_max, constants_class):
        assert len(E_states) == len(I_states), "E_states and I_states must match in length"

        self.constants = constants_class(mass_t, mass_p, E_lab, E_states)
        self.I_states = I_states
        self.pi_xp = pi_xp
        self.pi_xt = pi_xt
        self.J_tot_max = J_tot_max

    @staticmethod
    def allowed_parity_waves_grouping(J_tot, I, pi_xp, pi_xt):
        l_values = np.arange(abs(J_tot - I), J_tot + I + 1)
        parities = ((-1) ** l_values) * pi_xt * pi_xp

        pos_par_l = [(int(l), I) for l in l_values[parities == 1]]
        neg_par_l = [(int(l), I) for l in l_values[parities == -1]]

        return pos_par_l, neg_par_l

    def matrix_quantum_numbers(self, J_tot):
        stacked_pos, stacked_neg = [], []

        for I in self.I_states:
            pos_l, neg_l = self.allowed_parity_waves_grouping(J_tot, I, self.pi_xp, self.pi_xt)
            stacked_pos.extend(pos_l)
            stacked_neg.extend(neg_l)

        pos = np.array(stacked_pos, dtype=int) if stacked_pos else np.empty((0, 2), dtype=int)
        neg = np.array(stacked_neg, dtype=int) if stacked_neg else np.empty((0, 2), dtype=int)

        I_initial = self.I_states[0]

        if not np.any(pos[:, 1] == I_initial):
            pos = np.empty((0, 2), dtype=int)
        if not np.any(neg[:, 1] == I_initial):
            neg = np.empty((0, 2), dtype=int)

        def build_matrix(channel_array):
            if channel_array.shape[0] == 0:
                return np.empty((0, 0, 4), dtype=int)
            return np.concatenate([
                channel_array[:, None, :].repeat(len(channel_array), axis=1),
                channel_array[None, :, :].repeat(len(channel_array), axis=0)
            ], axis=2)

        matrix_pos = build_matrix(pos)
        matrix_neg = build_matrix(neg)

        return matrix_pos, matrix_neg

    def matrix_J_max(self):
        pos_matrix_array, neg_matrix_array = [], []

        for J_tot in range(int(self.J_tot_max) + 1):
            pos_matrix, neg_matrix = self.matrix_quantum_numbers(J_tot)

            if pos_matrix.size:
                J_tot_col_pos = np.full((*pos_matrix.shape[:2], 1), J_tot)
                pos_matrix_array.append(np.concatenate((pos_matrix, J_tot_col_pos), axis=2))

            if neg_matrix.size:
                J_tot_col_neg = np.full((*neg_matrix.shape[:2], 1), J_tot)
                neg_matrix_array.append(np.concatenate((neg_matrix, J_tot_col_neg), axis=2))

        return pos_matrix_array, neg_matrix_array

    def couplings_J_max(self, Q):
        couplings_total_pos, couplings_total_neg = [], []
        pos_matrix_array, neg_matrix_array = self.matrix_J_max()

        for matrix in pos_matrix_array:
            V = np.zeros((len(matrix), len(matrix)), dtype=np.complex128)
            for i in range(len(matrix)):
                for j in range(len(matrix)):
                    l_f, I_f, l_i, I_i, J_tot = matrix[i][j]
                    V[i][j] = coupling_matrix_elements(I_i, l_i, 0, I_f, l_f, 0, 0, J_tot, Q)
            couplings_total_pos.append(V)

        for matrix in neg_matrix_array:
            V = np.zeros((len(matrix), len(matrix)), dtype=np.complex128)
            for i in range(len(matrix)):
                for j in range(len(matrix)):
                    l_f, I_f, l_i, I_i, J_tot = matrix[i][j]
                    V[i][j] = coupling_matrix_elements(I_i, l_i, 0, I_f, l_f, 0, 0, J_tot, Q)
            couplings_total_neg.append(V)

        return couplings_total_pos, couplings_total_neg, pos_matrix_array, neg_matrix_array

    def energy_centrifugal_arrays(self):
        E_pos_tot, E_neg_tot = [], []
        l_pos_tot, l_neg_tot = [], []

        I_initial = self.I_states[0]

        for J_tot in range(int(self.J_tot_max) + 1):
            pos_group, neg_group = [], []
            E_pos_group, E_neg_group = [], []

            for i, I_i in enumerate(self.I_states):
                pos_l, neg_l = self.allowed_parity_waves_grouping(J_tot, I_i, self.pi_xp, self.pi_xt)

                if pos_l:
                    E = np.full(len(pos_l), self.constants.E_lab_to_COM()[i])
                    pos_group.extend(pos_l)
                    E_pos_group.extend(E)

                if neg_l:
                    E = np.full(len(neg_l), self.constants.E_lab_to_COM()[i])
                    neg_group.extend(neg_l)
                    E_neg_group.extend(E)

            if pos_group:
                pos = np.array(pos_group)
                if np.any(pos[:, 1] == I_initial):
                    l_pos_tot.append(pos[:, 0])
                    E_pos_tot.append(np.array(E_pos_group))

            if neg_group:
                neg = np.array(neg_group)
                if np.any(neg[:, 1] == I_initial):
                    l_neg_tot.append(neg[:, 0])
                    E_neg_tot.append(np.array(E_neg_group))

        return E_pos_tot, E_neg_tot, l_pos_tot, l_neg_tot