from functools import partial
import jax
import jax.numpy as jnp
from jax import Array
import numpy as np
from jax import device_put
from typing import Callable
from jax import jit, vmap, lax
from jax import config
from typing import Any
from functools import partial


class Multi_Energy_Solver:
    def __init__(self,
                 k_incoming : Any,
                 b : Array,
                 Hp_dict: dict,                  ## energy-dependent for batching
                 Hpp_dict: dict,                 ## energy-dependent for batching
                 Hm_dict: dict,                  ## energy-dependent for batching
                 Hmp_dict: dict,                 ## energy-dependent for batching
                 appended_couplings_dict: dict,  #fixed for all energies, but shapes must be compatible with energy-dependent matrices
                 free_matrix_dict: dict,         ## energy-dependent for batching
                 spin_proj_dict: dict,           ## fixed for all energies but shapes must be compatible with energy-dependent matrices
                 sqrt_k_dict: dict,              ## energy-dependent for batching
                 sqrt_k_inv_dict: dict,          ## energy-dependent for batching
                 keys : Array,
                 hbar_2mu : float,
                 a : float,
                 nbasis : int,
                 n_int : int,
                 multi_energy: bool = False,
                 num_energies: int= None,
                 dtype = jnp.complex64,
                 incoming_index: int = 0):
        
        if dtype == jnp.complex128:
            config.update("jax_enable_x64", True)
        
        devices = jax.devices()
        gpu_available = any(device.platform == 'gpu' for device in devices)
        if gpu_available:
            print("GPU available. Using GPU.")
            self.device = jax.devices("gpu")[0]
        else:
            print(" No GPU found. Using CPU.")
            self.device = jax.devices("cpu")[0]

        
        self.nbasis = nbasis
        self.hbar_2mu = hbar_2mu
        self.a = a
        self.n_int = n_int
        self.multi_energy = multi_energy
        self.num_energies = num_energies
        self.dtype = dtype
        self.incoming_index = incoming_index

        if multi_energy:
            assert num_energies is not None, "num_energies must be specified for multi-energy calculations."
            assert k_incoming.shape[0] == num_energies, "k_incoming must have shape (num_energies,)."
        else:
            assert k_incoming.shape[0] == 1, "k_incoming must have shape (1,) for single energy calculations."


        ## Transfer all inputs to the device
        self.keys = keys  # (keys: nbatch, nchannels)
        self.b = device_put(jnp.array(b, dtype=self.dtype), device=self.device)   # (nbasis,)
        
        ########### NOT USED YET, DONT FORGET TO USE IT
        self.k_incoming = device_put(jnp.array(k_incoming, dtype=self.dtype), device=self.device)  # (E_labs)
        ###########
        self.Hp_dict = self.transform_to_jnp_array_and_transfer(Hp_dict, keys)  # (keys: nbatch, nchannels, nchannels)
        self.Hpp_dict = self.transform_to_jnp_array_and_transfer(Hpp_dict, keys) # (keys: nbatch, nchannels, nchannels)
        self.Hm_dict = self.transform_to_jnp_array_and_transfer(Hm_dict, keys)  # (keys: nbatch, nchannels, nchannels)
        self.Hmp_dict = self.transform_to_jnp_array_and_transfer(Hmp_dict, keys)  # (keys: nbatch, nchannels, nchannels)
        self.appended_couplings_dict = self.transform_to_jnp_array_and_transfer(appended_couplings_dict, keys)  # (keys: n_int, nbatch, nchannels, nchannels)
        
        self.free_matrix_dict = self.transform_to_jnp_array_and_transfer(free_matrix_dict, keys)  # (keys: nbatch, nchannels * nbasis, nchannels * nbasis)
        self.spin_proj_dict = self.transform_to_jnp_array_and_transfer(spin_proj_dict, keys)
        self.sqrt_k_dict = self.transform_to_jnp_array_and_transfer(sqrt_k_dict, keys)  # (keys: nbatch, nchannels)
        self.sqrt_k_inv_dict = self.transform_to_jnp_array_and_transfer(sqrt_k_inv_dict, keys)  # (keys: nbatch, nchannels)
        
        

        self.potential_fn_dict = self.generate_coupling_interaction_factory()
        self.scat_amp_fn_compiled = self.scat_amp_fn_factory()
        if self.multi_energy:
            self.index_pair_dict = self.generate_energy_index_pairs() #for slicing the energy arrays
            self.multi_channel_scat_amp_fn_dict = self.process_scat_amp_fn_factory()




    def process_scat_amp_fn_factory(self):
        multi_channel_scat_amp_fn_dict = {}
        k_in = self.k_incoming
        for key in self.keys:
            E_batch, nch,nch =self.Hp_dict[key].shape
            second_dim = E_batch // self.num_energies
            num_energies = self.num_energies
            
            @jax.jit
            def process_scat_amp_fn(scat_amp : Array) -> Array:
                scat_amp = scat_amp = jnp.reshape(scat_amp, (num_energies, second_dim, nch, 5, 5, 181))
                scat_amp = scat_amp[:]/ k_in[:, None, None, None, None, None] 
                scat_amp = jnp.sum(scat_amp, axis=1)
                scat_amp_channel_sum_per_energy_elastic = jnp.sum(scat_amp[:, :1, : , : ,:], axis=1)  # Sum over nch, for the first channel
                scat_amp_channel_sum_per_energy_inelastic = jnp.sum(scat_amp[:, 1:, : , : ,:], axis=1)  # Sum over nch, excluding the first channel

                return scat_amp_channel_sum_per_energy_elastic, scat_amp_channel_sum_per_energy_inelastic

            dummy_input = jnp.ones((E_batch, nch, 5, 5, 181), dtype=self.dtype)
            scat_amp_elastic, scat_amp_inelastic = process_scat_amp_fn(dummy_input)

            multi_channel_scat_amp_fn_dict[key] = process_scat_amp_fn

        return multi_channel_scat_amp_fn_dict



    def cross_section_solver(self, appended_block_jax: Array) -> Array :
        if self.multi_energy:
            empty_per_energy_list_elastic = jnp.zeros((self.num_energies, 5, 5, 181), dtype=self.dtype) 
            empty_per_energy_list_inelastic = jnp.zeros((self.num_energies, 5, 5, 181), dtype=self.dtype) 
            appended_block_jax = device_put(jnp.array(appended_block_jax, dtype=self.dtype), device=self.device)  # (n_int, nbasis, nbasis)
            for key in self.keys:
                scat_amp = self.scat_amp_fn_compiled[key](appended_block_jax) #(total_batch, nch, msI, msF, angles)
                scat_amp_channel_sum_per_energy_elastic, scat_amp_channel_sum_per_energy_inelastic = self.multi_channel_scat_amp_fn_dict[key](scat_amp)
                empty_per_energy_list_elastic += scat_amp_channel_sum_per_energy_elastic
                empty_per_energy_list_inelastic += scat_amp_channel_sum_per_energy_inelastic

            empty_per_energy_list_elastic_sqr = empty_per_energy_list_elastic * jnp.conj(empty_per_energy_list_elastic)
            empty_per_energy_list_inelastic_sqr = empty_per_energy_list_inelastic * jnp.conj(empty_per_energy_list_inelastic)
            cross_sections_elastic = jnp.sum(empty_per_energy_list_elastic_sqr, axis=(1, 2))
            cross_sections_inelastic = jnp.sum(empty_per_energy_list_inelastic_sqr, axis=(1, 2))
            return cross_sections_elastic, cross_sections_inelastic

        else:
            #print("Single energy cross section calculation.")
            kinv = (1/self.k_incoming[0])
            scat_amp_elastic_tot = jnp.zeros((5, 5, 181), dtype=self.dtype) # nch, msI, msF, angles
            scat_amp_inelastic_tot = jnp.zeros((5, 5, 181), dtype=self.dtype) # msI, msF, angles
            appended_block_jax = device_put(jnp.array(appended_block_jax, dtype=self.dtype), device=self.device)  # (n_int, nbasis, nbasis)
            for key in self.keys:
                scat_amp = self.scat_amp_fn_compiled[key](appended_block_jax)
                scat_amp_sum = jnp.sum(scat_amp * kinv, axis=0)  # Sum over batch
                scat_amp_elastic_sum = jnp.sum( scat_amp_sum[:1, :, :, :], axis=0)  # Sum over nch #shape (msI, msF, angles)
                scat_amp_inelastic_sum = jnp.sum(scat_amp_sum[1:, :, :, :], axis=0)  # Sum over nch #shape (msI, msF, angles)
                scat_amp_elastic_tot += scat_amp_elastic_sum
                scat_amp_inelastic_tot += scat_amp_inelastic_sum

            amplitude_elastic  = scat_amp_elastic_tot * jnp.conj(scat_amp_elastic_tot)
            amplitude_inelastic = scat_amp_inelastic_tot * jnp.conj(scat_amp_inelastic_tot)
            amplitude_elastic = jnp.sum(amplitude_elastic, axis=(0,1))  # Sum over msI
            amplitude_inelastic = jnp.sum(amplitude_inelastic, axis=(0,1))  # Sum over msI
            return amplitude_elastic, amplitude_inelastic











    # def cross_section_solver(self, appended_block_jax: Array) -> Array :
    #     if self.multi_energy:
    #         empty_per_energy_list_elastic = jnp.zeros((self.num_energies, 5, 5, 181), dtype=self.dtype) 
    #         empty_per_energy_list_inelastic = jnp.zeros((self.num_energies, 5, 5, 181), dtype=self.dtype) 
    #         appended_block_jax = device_put(jnp.array(appended_block_jax, dtype=self.dtype), device=self.device)  # (n_int, nbasis, nbasis)
    #         for key in self.keys:
    #             scat_amp = self.scat_amp_fn_compiled[key](appended_block_jax) #(total_batch, nch, msI, msF, angles)
    #             en_batch,nch, _, _, _ = scat_amp.shape
    #             second_dim = en_batch // self.num_energies
    #             scat_amp = jnp.reshape(scat_amp, (self.num_energies, second_dim, nch, 5, 5, 181))  # Reshape to (num_energies, energy_batch, nch, msI, msF, angles)
    #             scat_amp = scat_amp[:]/ self.k_incoming[:, None, None, None, None, None]  # Divide by k_incoming for each energy
    #             scat_amp = jnp.sum(scat_amp, axis=1)  # Sum over energy_batch num_energies, nch, msI, msF, angles
    #             scat_amp_channel_sum_per_energy_elastic = jnp.sum(scat_amp[:, :1, : , : ,:], axis=1)  # Sum over nch, for the first channel
    #             scat_amp_channel_sum_per_energy_inelastic = jnp.sum(scat_amp[:, 1:, : , : ,:], axis=1)  # Sum over nch, excluding the first channel
    #             empty_per_energy_list_elastic += scat_amp_channel_sum_per_energy_elastic
    #             empty_per_energy_list_inelastic += scat_amp_channel_sum_per_energy_inelastic

    #         # this is ok!!!
    #         empty_per_energy_list_elastic_sqr = empty_per_energy_list_elastic * jnp.conj(empty_per_energy_list_elastic)
    #         empty_per_energy_list_inelastic_sqr = empty_per_energy_list_inelastic * jnp.conj(empty_per_energy_list_inelastic)
    #         cross_sections_elastic = jnp.sum(empty_per_energy_list_elastic_sqr, axis=(1, 2))
    #         cross_sections_inelastic = jnp.sum(empty_per_energy_list_inelastic_sqr, axis=(1, 2))
    #         return cross_sections_elastic, cross_sections_inelastic

    #     else:
    #         #print("Single energy cross section calculation.")
    #         kinv = (1/self.k_incoming[0])
    #         scat_amp_elastic_tot = jnp.zeros((5, 5, 181), dtype=self.dtype) # nch, msI, msF, angles
    #         scat_amp_inelastic_tot = jnp.zeros((5, 5, 181), dtype=self.dtype) # msI, msF, angles
    #         appended_block_jax = device_put(jnp.array(appended_block_jax, dtype=self.dtype), device=self.device)  # (n_int, nbasis, nbasis)
    #         for key in self.keys:
    #             scat_amp = self.scat_amp_fn_compiled[key](appended_block_jax)
    #             scat_amp_sum = jnp.sum(scat_amp * kinv, axis=0)  # Sum over batch
    #             scat_amp_elastic_sum = jnp.sum( scat_amp_sum[:1, :, :, :], axis=0)  # Sum over nch #shape (msI, msF, angles)
    #             scat_amp_inelastic_sum = jnp.sum(scat_amp_sum[1:, :, :, :], axis=0)  # Sum over nch #shape (msI, msF, angles)
    #             scat_amp_elastic_tot += scat_amp_elastic_sum
    #             scat_amp_inelastic_tot += scat_amp_inelastic_sum

    #         amplitude_elastic  = scat_amp_elastic_tot * jnp.conj(scat_amp_elastic_tot)
    #         amplitude_inelastic = scat_amp_inelastic_tot * jnp.conj(scat_amp_inelastic_tot)
    #         amplitude_elastic = jnp.sum(amplitude_elastic, axis=(0,1))  # Sum over msI
    #         amplitude_inelastic = jnp.sum(amplitude_inelastic, axis=(0,1))  # Sum over msI
    #         return amplitude_elastic, amplitude_inelastic






    


    # def cross_section_solver_2(self, appended_block_jax: Array) -> Array:
    #     if self.multi_energy:
    #         empty_per_energy_list_elastic = [jnp.zeros((5, 5, 181), dtype=self.dtype) for _ in range(self.num_energies)]
    #         empty_per_energy_list_inelastic = [jnp.zeros((5, 5, 181), dtype=self.dtype) for _ in range(self.num_energies)]
    #         appended_block_jax = device_put(jnp.array(appended_block_jax, dtype=self.dtype), device=self.device)  # (n_int, nbasis, nbasis)
    #         for key in self.keys:
    #             scat_amp = self.scat_amp_fn_compiled[key](appended_block_jax) #(total_batch, nch, msI, msF, angles)
    #             for i in range(self.num_energies):
    #                 start, end = self.index_pair_dict[key][i]
    #                 scat_amp_per_energy = scat_amp[start:end, :, :, :, :]  # (energy_batch, nch, msI, msF, angles)
    #                 scat_amp_sum_per_energy = jnp.sum(scat_amp_per_energy * (1 / self.k_incoming[i]), axis=0)  # (nch, msI, msF, angles)
    #                 scat_amp_channel_sum_per_energy_elastic = jnp.sum(scat_amp_sum_per_energy[:1, :, :, :], axis=0)  # Sum over nch, for the first channel
    #                 scat_amp_channel_sum_per_energy_inelastic = jnp.sum(scat_amp_sum_per_energy[1:, :, :, :], axis=0)  # Sum over nch, excluding the first channel
    #                 empty_per_energy_list_elastic[i] += scat_amp_channel_sum_per_energy_elastic
    #                 empty_per_energy_list_inelastic[i] += scat_amp_channel_sum_per_energy_inelastic
    #         cross_sections_elastic, cross_sections_inelastic = [], []
    #         for amp_el, amp_ine in zip(empty_per_energy_list_elastic, empty_per_energy_list_inelastic):
    #             amp_sq_el = amp_el * jnp.conj(amp_el)
    #             amp_sq_ine = amp_ine * jnp.conj(amp_ine)
    #             amp_sq_sum_el = jnp.sum(amp_sq_el, axis=(0, 1))
    #             amp_sq_sum_ine = jnp.sum(amp_sq_ine, axis=(0, 1))
    #             cross_sections_elastic.append(amp_sq_sum_el)
    #             cross_sections_inelastic.append(amp_sq_sum_ine)
    #         return cross_sections_elastic, cross_sections_inelastic
    #     else:
    #         #print("Single energy cross section calculation.")
    #         kinv = (1/self.k_incoming[0])
    #         scat_amp_elastic_tot = jnp.zeros((5, 5, 181), dtype=self.dtype) # nch, msI, msF, angles
    #         scat_amp_inelastic_tot = jnp.zeros((5, 5, 181), dtype=self.dtype) # msI, msF, angles
    #         appended_block_jax = device_put(jnp.array(appended_block_jax, dtype=self.dtype), device=self.device)  # (n_int, nbasis, nbasis)
    #         for key in self.keys:
    #             scat_amp = self.scat_amp_fn_compiled[key](appended_block_jax)
    #             scat_amp_sum = jnp.sum(scat_amp * kinv, axis=0)  # Sum over batch


    #             scat_amp_elastic_sum = jnp.sum( scat_amp_sum[:1, :, :, :], axis=0)  # Sum over nch #shape (msI, msF, angles)
    #             scat_amp_inelastic_sum = jnp.sum(scat_amp_sum[1:, :, :, :], axis=0)  # Sum over nch #shape (msI, msF, angles)
    #             scat_amp_elastic_tot += scat_amp_elastic_sum
    #             scat_amp_inelastic_tot += scat_amp_inelastic_sum

    #         amplitude_elastic  = scat_amp_elastic_tot * jnp.conj(scat_amp_elastic_tot)
    #         amplitude_inelastic = scat_amp_inelastic_tot * jnp.conj(scat_amp_inelastic_tot)
    #         amplitude_elastic = jnp.sum(amplitude_elastic, axis=(0,1))  # Sum over msI
    #         amplitude_inelastic = jnp.sum(amplitude_inelastic, axis=(0,1))  # Sum over msI
    #         return amplitude_elastic, amplitude_inelastic



        
        

    # def cross_section_solver(self, appended_block_jax: Array) -> Array:
    #     if self.multi_energy:
    #         empty_per_energy_list = self.empty_channel_list  # List to hold empty channels for multi-energy
    #         appended_block_jax = device_put(jnp.array(appended_block_jax, dtype=self.dtype), device=self.device)  # (n_int, nbasis, nbasis)
    #         for key in self.keys:
    #             scat_amp = self.scat_amp_fn_compiled[key](appended_block_jax) #(total_batch, nch, msI, msF, angles)
    #             for i in range(self.num_energies):
    #                 start, end = self.index_pair_dict[key][i]
    #                 scat_amp_per_energy = scat_amp[start:end, :, :, :, :]  # (energy_batch, nch, msI, msF, angles)
    #                 scat_amp_sum_per_energy = jnp.sum(scat_amp_per_energy * (1 / self.k_incoming[i]), axis=0)  # (nch, msI, msF, angles)
    #                 empty_per_energy_list[i] += scat_amp_sum_per_energy
    #         cross_sections = []
    #         for amp in empty_per_energy_list:
    #             amp_sq = amp * jnp.conj(amp)
    #             amp_sq_sum = jnp.sum(amp_sq, axis=(0, 1))
    #             cross_sections.append(amp_sq_sum)
    #         return cross_sections

    #     else:
    #         appended_block_jax = device_put(jnp.array(appended_block_jax, dtype=self.dtype), device=self.device)  # (n_int, nbasis, nbasis)

    #         for _ in range(len(self.channel_slices) - 1):
    #             scat_amp_tot_list.append(jnp.zeros((5, 5, 181), dtype=self.dtype))  # msI, msF, angles

    #         for key in self.keys:
    #             scat_amp = self.scat_amp_fn_compiled[key](appended_block_jax)  # (nch, msI, msF, angles, batch)
    #             scat_amp_sum = jnp.sum(scat_amp * (1 / self.k_incoming[0]), axis=0)  # (nch, msI, msF, angles)

    #             for i in range(len(self.channel_slices) - 1):
    #                 i_start = self.channel_slices[i]
    #                 i_end = self.channel_slices[i + 1]
    #                 amp = jnp.sum(scat_amp_sum[i_start:i_end, :, :, :], axis=0)
    #                 scat_amp_tot_list[i] += amp

    #         amplitudes = []
    #         for amp in scat_amp_tot_list:
    #             amp_sq = amp * jnp.conj(amp)
    #             amp_sq_sum = jnp.sum(amp_sq, axis=(0, 1))  # sum over msI, msF
    #             amplitudes.append(amp_sq_sum)

    #         return tuple(amplitudes)

    def scat_amp_fn_factory(self) -> Callable:
        # free_batch, b, Hp, Hpp, Hm, Hmp, nchannels, nbasis, a, hbar_2mu
        scat_amp_fn_dict = {}
        for key in self.keys:
            free_batch = self.free_matrix_dict[key]
            b = self.b
            Hp = self.Hp_dict[key]
            Hpp = self.Hpp_dict[key]
            Hm = self.Hm_dict[key]
            Hmp = self.Hmp_dict[key]
            nchannels = key
            nbasis = self.nbasis
            a = self.a
            hbar_2mu = self.hbar_2mu
            sqrt_k_arr = self.sqrt_k_dict[key]
            sqrt_k_inv_arr = self.sqrt_k_inv_dict[key]
            diag = jnp.eye(nchannels, dtype=self.dtype)
            potential_fn = self.potential_fn_dict[key] #fusing this jit function with the appended_couplings_jax for simplicity and speed
            spin_proj = self.spin_proj_dict[key]
            incoming_index = self.incoming_index
            batch_size = free_batch.shape[0]
            n_int = self.n_int
            # diag = jnp.tile(diag, (Hp.shape[0], 1, 1))
            @jax.jit
            def scat_amp_fn(appended_block_jax: Array,):
                """
                Computes the batched S-matrix:
                    R_ij = hbar²/(2μ) * a * b_m * C_imjn * b_n
                    S_ij = [Hp_ij + Hpp_ik @ R_kj]^-1 @ [Hm_ij + Hmp_ik @ R_kj]
                where C = A⁻¹.
                See Eq. (15) in Descouvemont, 2016.

                Args:
                    A_batch: (batch_size, nchannels*nbasis, nchannels*nbasis)
                    b: (nbasis,)
                    Hp : (batch_size, nchannels, nchannels) : H^+ Coulomb funtions at the channel radius r 
                    Hpp : (batch_size, nchannels, nchannels) : derivative of the H^+ Coulomb funtions at the channel radius r
                    Hm : (batch_size, nchannels, nchannels) : H^- Coulomb funtions at the channel radius r
                    Hmp : (batch_size, nchannels, nchannels) : derivative of the H^- Coulomb funtions at the channel radius r
                    nchannels, nbasis: channel and basis size
                    a: channel radius
                    hbar_2mu: ħ² / 2μ

                Returns:
                    S_batch: (batch_size, nchannels, nchannels)
                """
                interaction_batch = potential_fn(appended_block_jax)  # (batch_size, nchannels * nbasis, nchannels * nbasis)
                
                C_batch = jnp.linalg.inv((free_batch + interaction_batch))
                
                C_blocks = C_batch.reshape(C_batch.shape[0], nchannels, nbasis, nchannels, nbasis)
                
                R_batch = (hbar_2mu / a**2)  * jnp.einsum('m,binjm,n -> bij', b, C_blocks, b)

                Zp = Hp - a * jnp.einsum('bij,bjk->bik', R_batch, Hpp)
                Zm = Hm - a * jnp.einsum('bij,bjk->bik', R_batch, Hmp)

                S_batch = jnp.linalg.solve(Zp, Zm)

                S_batch_scaled = (jnp.einsum('ijk,ikl, iln -> ijn', sqrt_k_arr, S_batch, sqrt_k_inv_arr)) - diag 

                scat_amp = S_batch_scaled[:, : , incoming_index, jnp.newaxis, jnp.newaxis, jnp.newaxis] * spin_proj
                
                return  scat_amp
            
            if self.multi_energy:
                #dummy_input = jnp.zeros((n_int, batch_size, nbasis, nbasis), dtype=self.dtype)
                dummy_input = jnp.zeros((n_int, nbasis, nbasis), dtype=self.dtype)
            else:
                dummy_input = jnp.zeros((n_int, nbasis, nbasis), dtype=self.dtype)

            # Force compilation using dummy input
            _ = scat_amp_fn(dummy_input)

            scat_amp_fn_dict[key] = scat_amp_fn

        return scat_amp_fn_dict
    


    # def generate_coupling_interaction_factory(self):
    #     """
    #     Generates a dictionary mapping:
    #         number of channels (nch) → JIT-compiled interaction function,
    #     where the interaction block (nbasis x nbasis) is shared across all batch entries.

    #     Each returned function maps:
    #         appended_block_jax: (n_int, nbasis, nbasis)
    #         → V_total: (batch_size, nch * nbasis, nch * nbasis)

    #     This assumes appended_couplings_dict[key] has shape (n_int, batch_size, nch, nch)
    #     and the interaction block is *not* batched across batch_size.
    #     """
    #     potential_fn_dict = {}

    #     for key in self.keys:
    #         nchannels = key
    #         nbasis = self.nbasis
    #         appended_couplings_jax = self.appended_couplings_dict[key]  # shape: (n_int, batch, nch, nch)
    #         n_int, batch_size, _, _ = appended_couplings_jax.shape

    #         @jax.jit
    #         def generate_coupling_interaction(
    #             appended_block_jax,
    #             appended_couplings_jax=appended_couplings_jax,
    #             n_int=n_int,
    #             batch_size=batch_size,
    #             nchannels=nchannels,
    #             nbasis=nbasis
    #         ):
    #             """
    #             Computes V_total = Σ_i (C_i ⊗ V_i), where:
    #                 - appended_couplings_jax: (n_int, batch_size, nch, nch)
    #                 - appended_block_jax:     (n_int, nbasis, nbasis) [shared across batch]
    #             Returns:
    #                 - V_total: (batch_size, nch * nbasis, nch * nbasis)
    #             """
    #             # Shared interaction block gets broadcast across batch_size
    #             scaled_blocks = jnp.einsum('iljk,ilmn->iljmkn', appended_couplings_jax, appended_block_jax[:, jnp.newaxis, :, :])
    #             V_total = jnp.sum(
    #                 scaled_blocks.reshape(n_int, batch_size, nchannels * nbasis, nchannels * nbasis),
    #                 axis=0
    #             )
    #             return V_total

    #         # Compile using dummy input
    #         dummy_input = jnp.zeros((n_int, nbasis, nbasis), dtype=self.dtype)
    #         print(dummy_input.shape)
    #         print(appended_couplings_jax.shape)
    #         _ = generate_coupling_interaction(dummy_input)


    #         potential_fn_dict[key] = generate_coupling_interaction

    #     return potential_fn_dict

    
    def generate_coupling_interaction_factory(self):
        """
        Generates a dictionary mapping number of channels → JIT-compiled interaction function,
        with correct shape specialization via dummy call (no functools.partial needed).
        """
        potential_fn_dict = {}

        for key in self.keys:
            nchannels = key
            nbasis = self.nbasis
            appended_couplings_jax = self.appended_couplings_dict[key]  # (n_int, batch, nch, nch)
            n_int = appended_couplings_jax.shape[0]
            batch_size = appended_couplings_jax.shape[1]
            print(appended_couplings_jax.shape)

            if self.multi_energy:
                @jax.jit
                def generate_coupling_interaction(appended_block_jax):
                    #scaled_blocks = jnp.einsum('iljk,ilmn->iljmkn', appended_couplings_jax, appended_block_jax)
                    scaled_blocks = jnp.einsum('iljk,ilmn->iljmkn', appended_couplings_jax, appended_block_jax[:,None, :, :])
                    V_total = jnp.sum(scaled_blocks.reshape(n_int, batch_size, nchannels * nbasis, nchannels * nbasis), axis=0)
                    return V_total
                
                #dummy_input = jnp.zeros((n_int, batch_size, nbasis, nbasis), dtype=self.dtype)
                dummy_input = jnp.zeros((n_int, nbasis, nbasis), dtype=self.dtype)
            else:
                @jax.jit
                def generate_coupling_interaction(appended_block_jax):
                    scaled_blocks = jnp.einsum('iljk,ilmn->iljmkn', appended_couplings_jax, appended_block_jax[:,None,:])
                    V_total = jnp.sum(scaled_blocks.reshape(n_int, batch_size, nchannels * nbasis, nchannels * nbasis), axis=0)
                    return V_total
                dummy_input = jnp.zeros((n_int, nbasis, nbasis), dtype=self.dtype)

            # Force compilation using dummy input
            _ = generate_coupling_interaction(dummy_input)

            potential_fn_dict[key] = generate_coupling_interaction

        return potential_fn_dict
        









    # def generate_coupling_interaction_factory(self):
    #     """
    #     Generates a dictionary mapping number of channels → JIT-compiled interaction function,
    #     with frozen appended_couplings_jax for each key.
    #     """
    #     potential_fn_dict = {}

    #     for key in self.keys:
    #         nchannels = key
    #         nbasis = self.nbasis
    #         appended_couplings_jax = self.appended_couplings_dict[key]  # (n_int, batch, nch, nch)
    #         n_int = appended_couplings_jax.shape[0]
    #         batch_size = appended_couplings_jax.shape[1]
    #         print(batch_size)

    #         if self.multi_energy:
    #             @jax.jit
    #             def generate_coupling_interaction(appended_block_jax):
    #                 """
    #                 @params:
    #                     appended_block_jax: (n_int, batch, nb, nb), dynamic per elements in batch, this allows for energy-dependent parameters
    #                 @returns:
    #                     V_total: (batch, nch * nb, nch * nb)
    #                 """
    #                 # Correct: (n_int, batch, nch, nb, nch, nb)
    #                 scaled_blocks = jnp.einsum('iljk,ilmn->iljmkn', appended_couplings_jax, appended_block_jax) ##### CHECK THIS IS OK. 
    #                 V_total = jnp.sum(scaled_blocks.reshape(n_int, batch_size, nchannels * nbasis, nchannels * nbasis), axis=0)
    #                 return V_total  # shape: (batch, nch * nb, nch * nb)

    #             potential_fn_dict[key] = generate_coupling_interaction
    #         else:
    #             @jax.jit
    #             def generate_coupling_interaction(appended_block_jax):
    #                 """
    #                 @params:
    #                     appended_block_jax: (n_int, batch_size, nb, nb), dynamic per elements in batch, this allows for energy-dependent parameters
    #                 @returns:
    #                     V_total: (batch, nch * nb, nch * nb)
    #                 """
    #                 # Correct: (n_int, batch, nch, nb, nch, nb)
    #                 scaled_blocks = jnp.einsum('iljk,imn->iljmkn', appended_couplings_jax, appended_block_jax) ##### CHECK THIS IS OK. 
    #                 V_total = jnp.sum(scaled_blocks.reshape(n_int, batch_size, nchannels * nbasis, nchannels * nbasis), axis=0)
    #                 return V_total  # shape: (batch, nch * nb, nch * nb)

    #             potential_fn_dict[key] = generate_coupling_interaction

    #     return potential_fn_dict
    



    def transform_to_jnp_array_and_transfer(self, data: dict, keys: list) -> dict:
        """
        Transforms specified entries in a dictionary from NumPy arrays or lists to
        jax.numpy arrays of a given dtype, and transfers them to the current device.

        Args:
            data: Dictionary containing NumPy arrays or lists.
            keys: List of keys to convert and transfer.
            dtype: Desired JAX dtype (default: jnp.complex64).

        Returns:
            New dictionary with selected keys converted and transferred to device.
        """
        transformed = {}

        for key in keys:
            if key in data:
                value = data[key]
                if isinstance(value, jax.Array):
                    # Already JAX array — cast + transfer if needed
                    transformed[key] = jax.device_put(jnp.asarray(value, dtype=self.dtype), device=self.device)
                elif isinstance(value, (np.ndarray, list, tuple)):
                    # Convert NumPy or list → JAX array
                    transformed[key] = jax.device_put(jnp.array(value, dtype=self.dtype), device=self.device)
                else:
                    raise TypeError(f"Unsupported type for key '{key}': {type(value)}")

        return transformed
    

    def generate_energy_index_pairs(self) -> dict:
        """
        Generate start-end index pairs to slice a batch array into chunks corresponding to different energies.

        Args:
            num_energies: Number of energy slices to create.
            batch_dict: Dictionary of arrays, each with shape (batch_size, ...).
            keys: List of keys to process from the batch_dict.

        Returns:
            index_pair_dict: Dictionary where each key maps to a (num_energies, 2) JAX array of (start, end) pairs.
        """
        index_pair_dict = {}
        for key in self.keys:
            batch_size = self.Hp_dict[key].shape[0]
            batch_per_energy = batch_size // self.num_energies
            pairs = []

            for i in range(self.num_energies):
                start = i * batch_per_energy
                end = (i + 1) * batch_per_energy if i < self.num_energies - 1 else batch_size
                pairs.append((start, end))

            index_pair_dict[key] = jax.device_put(jnp.array(pairs, dtype=jnp.int32), device=self.device)

        return index_pair_dict
                
        


















    # def generate_coupling_interaction_factory(self):
    #     """
    #     Generates a function that computes the coupling interaction matrix for the appended couplings and
    #     the appended block array.
    #     @returns:
    #         potential_fn_dict: dict : a dictionary with keys as the number of channels and values as the function
    #                                    that computes the coupling interaction matrix for that number of channels.
    #     """

    #     potential_fn_dict = {}
        
    #     for key in self.keys:
    #         nchannels = key  # or use self.shapes_dict[key][2]
    #         precomp_fill_fn = Core_Solver.update_local_coupling_interaction_factory(nchannels, self.nbasis)
    #         appended_coupling_block_jax = self.appended_couplings_dict[key]  # (n_int, nchannels, nchannels)

    #         @jax.jit
    #         def generate_coupling_interaction(appended_couplings_jax, appended_block_jax, fn=precomp_fill_fn):
    #             # fuse both vmap + update_local_coupling_interaction in one
    #             per_block_V = jax.vmap(fn, in_axes=(0, 0))(appended_block_jax, appended_couplings_jax)
    #             V_total = jnp.sum(per_block_V, axis=0)
    #             return V_total  # (batch, nch*nb, nch*nb)

    #         potential_fn_dict[key] = generate_coupling_interaction

    #     return potential_fn_dict

    # @staticmethod
    # def update_local_coupling_interaction_factory(nchannels: int, nbasis: int):
    #     def update_local_coupling_interaction(block: Array,
    #                                         couplings_matrix: Array) -> Array:
    #         """
    #         Returns a (nchannels*nbasis, nchannels*nbasis) matrix where each (i, j) block = couplings_matrix[i,j] * diag(diag_vals)
    #         """
    #         scaled_blocks = couplings_matrix[:, None, :, None] * block[None, :, None, :]  # (nch, nb, nch, nb)
    #         return scaled_blocks.reshape(nchannels * nbasis, nchannels * nbasis)

    #     # Vectorize over batch dim 0 for both inputs
    #     return jax.jit(jax.vmap(update_local_coupling_interaction, in_axes=(0, 0)))

    
        # def generate_coupling_interaction_factory(self):
    #     """
    #     Generates a dictionary mapping number of channels → JIT-compiled interaction function,
    #     with frozen appended_couplings_jax.
    #     """
    #     potential_fn_dict = {}
        
    #     for key in self.keys:
    #         nchannels = key
    #         appended_couplings_jax = self.appended_couplings_dict[key]  # shape: (n_int, nch, nch)

    #         # Precompile per shape with couplings frozen in
    #         precomp_fill_fn = Core_Solver.update_local_coupling_interaction_factory(
    #             appended_couplings_jax, nchannels, self.nbasis
    #         )

    #         @jax.jit
    #         def generate_coupling_interaction(appended_block_jax, fn=precomp_fill_fn):
    #             per_block_V = fn(appended_block_jax)  # now only takes (n_int, nb, nb)
    #             return jnp.sum(per_block_V, axis=0)

    #         potential_fn_dict[key] = generate_coupling_interaction

    #     return potential_fn_dict


    # @staticmethod
    # def update_local_coupling_interaction_factory(appended_couplings_jax: Array, nchannels: int, nbasis: int):
    #     """
    #     Freezes the appended_couplings_jax tensor into the interaction function.
    #     Input block: (n_int, nb, nb)
    #     Returns: (batch, nch*nb, nch*nb)
    #     """
    #     def update_local_coupling_interaction(block: Array) -> Array:
    #         # `appended_couplings_jax` is already (n_int, nch, nch)
    #         scaled_blocks = (
    #             appended_couplings_jax[:, :, None, :, None] *
    #             block[:, None, :, None, :]
    #         )  # → (n_int, nch, nb, nch, nb)
            
    #         return scaled_blocks.reshape(appended_couplings_jax.shape[0], nchannels * nbasis, nchannels * nbasis)

    #     return jax.jit(update_local_coupling_interaction)


    # def generate_coupling_interaction_factory(self):
    #     """
    #     Generates a dictionary mapping number of channels → JIT-compiled interaction function,
    #     correctly closing over per-key shapes.
    #     """
    #     potential_fn_dict = {}

    #     def coupling_interaction_core(appended_block_jax, appended_couplings_jax, nchannels, nbasis, batch_size):
    #         """
    #         Core einsum function with fully frozen arguments (used in partial).
    #         """
    #         scaled_blocks = jnp.einsum('iljk,imn->iljmkn', appended_couplings_jax, appended_block_jax)
    #         V_total = jnp.sum(
    #             scaled_blocks.reshape(appended_couplings_jax.shape[0], batch_size, nchannels * nbasis, nchannels * nbasis),
    #             axis=0
    #         )
    #         return V_total
        
    #     def coupling_interaction_core_multi(appended_block_jax, appended_couplings_jax, nchannels, nbasis, batch_size):
    #         """
    #         Core einsum function with fully frozen arguments (used in partial).
    #         """
    #         scaled_blocks = jnp.einsum('iljk,ilmn->iljmkn', appended_couplings_jax, appended_block_jax)
    #         V_total = jnp.sum(
    #             scaled_blocks.reshape(appended_couplings_jax.shape[0], batch_size, nchannels * nbasis, nchannels * nbasis),
    #             axis=0
    #         )
    #         return V_total
        


    #     for key in self.keys:
    #         nchannels = key
    #         nbasis = self.nbasis
    #         appended_couplings_jax = self.appended_couplings_dict[key]  # (n_int, batch, nch, nch)
    #         batch_size = appended_couplings_jax.shape[1]

    #         # Freeze data explicitly using partial

    #         if self.multi_energy:
    #             # For multi-energy, we use the core function with shapes baked in
    #             frozen_fn = partial(coupling_interaction_core_multi,
    #                                 appended_couplings_jax=appended_couplings_jax,
    #                                 nchannels=nchannels,
    #                                 nbasis=nbasis,
    #                                 batch_size=batch_size)
    #         else:
    #             frozen_fn = partial(coupling_interaction_core,
    #                                 appended_couplings_jax=appended_couplings_jax,
    #                                 nchannels=nchannels,
    #                                 nbasis=nbasis,
    #                                 batch_size=batch_size)

    #         # JIT compile the version with shapes baked in
    #         potential_fn_dict[key] = jax.jit(frozen_fn)

    #     return potential_fn_dict
    