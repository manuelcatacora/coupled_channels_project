#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 23 16:35:49 2025

@author: manuelfranciscocatacorarios
"""

import numpy as np
import os
import re
import subprocess


class Frescox_Inelastic_Wrapper:
    def __init__(
        self,
        mass_t: float,
        charge_t: float,
        mom_states: np.ndarray,
        mass_p: float,
        charge_p: float,
        spin_p: float,
        E_lab: float,
        J_tot_max: float,
        J_tot_min: float,
        coulomb_r: float,
        reaction_name: str,
        E_states: np.ndarray,
    ):
        """
        Initialize the Frescox_Inelastic_Wrapper with reaction parameters.
        """
        self.mass_t = mass_t
        self.charge_t = charge_t
        self.mom_states = mom_states
        self.mass_p = mass_p
        self.charge_p = charge_p
        self.spin_p = spin_p
        self.E_lab = E_lab
        self.J_tot_max = J_tot_max
        self.J_tot_min = J_tot_min
        self.coulomb_r = coulomb_r
        self.reaction_name = reaction_name
        self.E_states = E_states
        self.template_file = "frescox_full_template.in"
        self.template_instance_file = f"{self.reaction_name}_input.in"

        if len(E_states) != len(mom_states):
            raise ValueError(
                "Number of excited states must match the number of spin states of the target."
            )
        
        self.initialize_template = self.generate_template_inelastic()


    @staticmethod
    def modify_template_in_memory(template: str, values_et: np.ndarray, values_jt: np.ndarray) -> str:
        """
        Modify the template content in memory with new &STATES sections.
        This ensures that the placeholder line for &STATES is removed and replaced.
        """
        # Split the template into lines for easier manipulation
        lines = template.splitlines()

        # Remove any placeholder lines containing the original &STATES placeholder
        placeholder_pattern = "&STATES copyp=1"
        lines = [line for line in lines if placeholder_pattern not in line]

        # Generate the dynamic &STATES section
        dynamic_section = "".join(
            f"&STATES copyp=1         cpot=1 jt={jt} bandt=1 et={et} /\n"
            for et, jt in zip(values_et[1:], values_jt[1:])  # Skip the first value (0.0)
            )

        # Convert the lines back into a string and replace the &partition / marker
        modified_template = "\n".join(lines)
        modified_template = modified_template.replace("&partition /", dynamic_section + "&partition /")

        return modified_template

    def generate_template_inelastic(self):
        """
        Generate and write the final Fresco input file with all parameters replaced.
        """
        # Read the template file once
        with open(self.template_file, "r") as file:
            template = file.read()

        # Modify the template in memory
        modified_template = self.modify_template_in_memory(template, self.E_states, self.mom_states)

        # Define placeholder replacements
        replacements = {
            "HEADER": self.reaction_name,
            "J_TOT_MIN": str(self.J_tot_min),
            "J_TOT_MAX": str(self.J_tot_max),
            "E_LAB": str(self.E_lab),
            "MASS_P": str(self.mass_p),
            "CHARGE_P": str(self.charge_p),
            "MASS_T": str(self.mass_t),
            "CHARGE_T": str(self.charge_t),
            "S_PROJECTILE": str(self.spin_p),
            "I_GROUND": str(self.mom_states[0]),
            "E_GROUND": str(self.E_states[0]),
            "COULOMB_R": str(self.coulomb_r),
        }

        # Replace placeholders directly in the modified template
        for placeholder, value in replacements.items():
            modified_template = modified_template.replace(placeholder, value)

        # Write the final content to the output file
        with open(self.template_instance_file, "w") as file:
            file.write(modified_template)
        
        #print(f"Generated input file: {self.template_instance_file}")

    
    def generate_input_file_inelastic(self, delta_lambda:float, alpha: np.ndarray):
        """
        Replace 'XXXXX' placeholders in the Frescox input file with parameters from the alpha array.
    
        Args:
            alpha (np.ndarray): Array of parameters to replace XXXXX.
        
        Raises:
            ValueError: If the number of 'XXXXX' placeholders doesn't match the length of alpha.
        """
        
        file = self.template_instance_file
        with open(file, "r") as f:
            content = f.readlines()

        # file = self.template_instance_file
        # if not os.path.exists(file):
        #     raise FileNotFoundError(f"{file} does not exist. Please generate it first.")

    
        # with open(file, "r") as f:
        #     content = f.readlines()

        # # Count and replace placeholders
        # total_placeholders = sum(line.count("XXXXX") for line in content)
        # if len(alpha) != total_placeholders:
        #     raise ValueError(
        #         f"Mismatch: {len(alpha)} values provided, but {total_placeholders} 'XXXXX' placeholders found."
        #         )


        placeholder_index = 0
        for idx, line in enumerate(content):
            while "XXXXX" in line:
                line = line.replace("XXXXX", str(alpha[placeholder_index]), 1)
                placeholder_index += 1
            content[idx] = line
        for idx, line in enumerate(content):
            if "DELTA_LAMBDA" in line:
                content[idx] = line.replace("DELTA_LAMBDA", str(delta_lambda))

        # Write the modified content to the temporary input file
        temp_file = f"{self.reaction_name}_temp_input.in"
        with open(temp_file, "w") as f:
            f.writelines(content)

        #print(f"Generated temporary input file: {temp_file}")
        
        
        
    def extract_partial_waves(self, 
                              file_extract='fort.17'):
        '''
        this code extracts from the fort.17 file the partial waves and adds them as dictionary with the keys
        corresponding to the different quantum numbers of the coupled set of differential equations. The keys are
        broken down as follows {coupled channel set,channel number,l',j',J, l, j}.
        '''
        keys_array = []
    
        # Initialize a dictionary to store the values
        data_dict = {}

        # Initialize a counter for lines starting with "401"
        count_401 = 0

        # Specify the file path
        file_path = file_extract

        # Regular expression pattern to match lines with the desired format
        pattern = re.compile(r'^\s*(\d+\s+\d+\s+\d+\.\d+\s+\d+\.\d+\s+\d+\s+\d+\.\d+)')
        
        pattern2 = re.compile(r'^\s*201\s+\d+\.\d+\s+\d+\.\d+\s+\d+\.\d+\s+-1\s+\d+\.\d+\s+\d+\.\d+\s+\d+\.\d+\s+\d+\.\d+')

        pattern3 = re.compile(r'^\s*-1\s+0\s+0\.0\s+0\.0\s+0\s+0\.0\s+0\.0{10}\s+0\.0{10}\s+0\.0{8}')

        # Open the file and read its contents
        with open(file_path, 'r') as file:
            lines = file.readlines()
        
        # Initialize a variable to hold the current key
        current_key = None

        # Iterate through the lines to find lines that match the pattern
        for i in range(len(lines)):
            line = lines[i].strip()
            match = pattern.match(line)
            if match:
                # Convert the first 6 values of the line to floats and use them as part of the key
                key_values = match.group(1).split()[:6]
                key_values = [float(value) for value in key_values]
                current_key = tuple([count_401] + key_values)
                # Initialize an empty list for the values associated with the key
                data_dict[current_key] = []
                i += 1  # Move to the next line to start reading values
                while i < len(lines)  and not lines[i].startswith("8001"):
                    # Split the current line into values
                    line2 = lines[i].strip()
                    match2 = pattern.match(line2)
                    line4 = lines[i].strip()
                    match4 = pattern3.match(line2)
                    if match2:
                        break
                    if match4:
                        i+=1
                    else:
                        values = lines[i].split()
                        # Convert values to floats and append them to the current key's list
                        data_dict[current_key].extend([float(value.replace('D', 'E')) for value in values])
                        i += 1
            elif lines[i].startswith("8001"):
                # Increment the counter for lines starting with "401"
                count_401 += 1
    
        keys_array = list(data_dict.keys())
  
    
        return data_dict, keys_array
    
    
    
    def wave_functions_format_imaginary(self, 
                                        file_extract='fort.17'):
        '''
        This function takes as input the fort.17 file and using the keys from the function extract_partial_waves
        then writes the wavefunction from the fresco output to \psi= real + imag
        '''
        waves_exact = {}
    
        data_dict, keys_array = self.extract_partial_waves()
    
        for key in keys_array:
            temp_real_array = []
            temp_imag_array = []
            temp_wave = data_dict.get(key)
            for i in range(len(np.array(temp_wave))):
                radial = temp_wave[i]
                if (i % 2 != 0):
                    temp_imag_array.append(radial)
                if (i % 2 == 0) :
                    temp_real_array.append(radial)
                
            waves_exact[key] = np.array(temp_real_array) + 1j* np.array(temp_imag_array)
        
        return waves_exact, keys_array

    
    def frescox_output_inelastic_wavefunctions(
              self,
              input_file=None,
              output_file="fort.17",
              working_dir="~/fewbody/house_r_matrix_root/house_r_matrix",
              frescox_executable="~/fewbody/Frescoxex/frescox",
              ):
          """
          Run FrescoX with the specified input file, extract wavefunctions, and clean up.
         
          Args:
              input_file (str): Path to the FrescoX input file (default: generated from reaction_name).
              output_file (str): Path to the FrescoX output file (default: "fort.17").
              working_dir (str): Directory where FrescoX is executed (default: "~/fewbody/CC_emulator").
              frescox_executable (str): Path to the FrescoX executable (default: "~/fewbody/Frescoxex/frescox").

          Returns:
              waves (dict): Extracted partial wavefunctions.
              keys (list): Corresponding quantum numbers as keys.

          Raises:
              FileNotFoundError: If the required files are missing.
              """
              # Set default input file if not provided
          if input_file is None:
              input_file = f"{self.reaction_name}_temp_input.in"

          # Format paths
          working_dir = os.path.expanduser(working_dir)
          frescox_executable = os.path.expanduser(frescox_executable)
          output_dir = os.path.join(working_dir, "frescox_outputs")
          os.makedirs(output_dir, exist_ok=True)

          # Command to run FrescoX
          command = (
              f"cd {working_dir} && "
              f"{frescox_executable} < {input_file} > {output_dir}/{self.reaction_name}_temp.out"
              #f"{frescox_executable} < {input_file} > {self.reaction_name}_temp.out"
              )

          # Execute FrescoX
          result = subprocess.run(command, capture_output=True, text=True, shell=True)



          # Extract wavefunctions from the output file
          try:
              waves, keys = self.wave_functions_format_imaginary(output_file)
              #print(waves,keys)
          except FileNotFoundError:
              raise FileNotFoundError(f"Output file '{output_file}' not found.")

          # Clean up temporary files
          for file_path in [input_file, output_file]:
              try:
                  os.remove(file_path)
              except FileNotFoundError:
                  pass  # Skip if the file doesn't exist

          return waves, keys
 
    
 
    def frescox_run_inelastic_waves(self, 
                                    alpha_array : np.array):
        '''
        This function takes as an input a set of parameters and for each parameter set generates a frescox
        input using the template form, and then runs frescox and extracts the wave functions. the outputs 
        are an array whose elements are dictionaries of the different partial waves corresponding to
        each set of paramters in theta, and the keys to the dictionaries.
        '''
        alpha_test = alpha_array[0, 1:]

        file = self.template_instance_file
        if not os.path.exists(file):
            raise FileNotFoundError(f"{file} does not exist. Please generate it first.")
    
        with open(file, "r") as f:
            content = f.readlines()
        # Count and replace placeholders
        total_placeholders = sum(line.count("XXXXX") for line in content)
        if len(alpha_test) != total_placeholders:
            raise ValueError(
                f"Mismatch: {len(alpha_test)} values provided, but {total_placeholders} 'XXXXX' placeholders found."
                )
        
        
        delta_lambda_arr = alpha_array[:, 0]
        alpha_array = alpha_array[:, 1:]
        waves_array = []
        for delta, para_obs in zip(delta_lambda_arr, alpha_array):
            self.generate_input_file_inelastic(delta, para_obs)
            waves_per_calc, keys_per_calc  = self.frescox_output_inelastic_wavefunctions()
            waves_array.append(waves_per_calc)

        return waves_array, keys_per_calc

    
    
    def frescox_output_inelastic_cross_sections(
             self,
             input_file=None,
             output_file="fort.16",
             working_dir="~/fewbody/house_r_matrix_root/house_r_matrix",
             frescox_executable="~/fewbody/Frescoxex/frescox",
             ):
         """
         Run FrescoX with the specified input file, extract wavefunctions, and clean up.
         
         Args:
             input_file (str): Path to the FrescoX input file (default: generated from reaction_name).
             output_file (str): Path to the FrescoX output file (default: "fort.16").
             working_dir (str): Directory where FrescoX is executed (default: "~/fewbody/CC_emulator").
             frescox_executable (str): Path to the FrescoX executable (default: "~/fewbody/Frescoxex/frescox").

         Returns:
             waves (dict): Extracted partial wavefunctions.
             keys (list): Corresponding quantum numbers as keys.

         Raises:
             FileNotFoundError: If the required files are missing.
             """
             # Set default input file if not provided
         if input_file is None:
             input_file = f"{self.reaction_name}_temp_input.in"

         # Format paths
         working_dir = os.path.expanduser(working_dir)
         frescox_executable = os.path.expanduser(frescox_executable)
         output_dir = os.path.join(working_dir, "frescox_outputs")
         os.makedirs(output_dir, exist_ok=True)

         # Command to run FrescoX
         command = (
             f"cd {working_dir} && "
             f"{frescox_executable} < {input_file} > {output_dir}/{self.reaction_name}_temp.out"
             #f"{frescox_executable} < {input_file} > {self.reaction_name}_temp.out"
             )

         # Execute FrescoX
         result = subprocess.run(command, capture_output=True, text=True, shell=True)
         
         

        # Read the output file
         try:
            with open(output_file, "r") as f:
                content = f.readlines()
         except FileNotFoundError:
            raise FileNotFoundError(f"Output file '{output_file}' not found.")

        # Parse the output for angles and cross sections
         angles = []
         cross_sections = []

         for line in content:
            line = line.strip()
            if line.startswith(("@", "#")) or not line:  # Skip metadata or empty lines
                continue
            try:
                parts = line.split()
                angles.append(float(parts[0]))
                cross_sections.append(float(parts[1]))
            except (ValueError, IndexError):
                continue  # Skip invalid lines

        # Convert lists to numpy arrays
         angles_array = np.array(angles)
         cross_sections_array = np.array(cross_sections)

         # Clean up temporary files
         for file_path in [input_file, output_file]:
            try:
                os.remove(file_path)
            except FileNotFoundError:
                pass  # Skip if the file doesn't exist

         return cross_sections_array, angles_array
    
    
    
    def frescox_run_inelastic_cross_sections(self, 
                                    alpha_array : np.array):
        '''
        This function takes as an input a set of parameters and for each parameter set generates a frescox
        input using the template form, and then runs frescox and extracts the wave functions. the outputs 
        are an array whose elements are dictionaries of the different partial waves corresponding to
        each set of paramters in theta, and the keys to the dictionaries.
        '''
        alpha_test = alpha_array[0, 1:]

        file = self.template_instance_file
        if not os.path.exists(file):
            raise FileNotFoundError(f"{file} does not exist. Please generate it first.")
    
        with open(file, "r") as f:
            content = f.readlines()
        # Count and replace placeholders
        total_placeholders = sum(line.count("XXXXX") for line in content)
        if len(alpha_test) != total_placeholders:
            raise ValueError(
                f"Mismatch: {len(alpha_test)} values provided, but {total_placeholders} 'XXXXX' placeholders found."
                )
        
        
        delta_lambda_arr = alpha_array[:, 0]
        alpha_array = alpha_array[:, 1:]
            
        f_l = []
        angles_output = None  # Initialize to ensure scope
        for delta, para_obs in zip(delta_lambda_arr, alpha_array):  # Directly iterate over NumPy array
            self.generate_input_file_inelastic(delta, para_obs)
            exp_output, angles_output = self.frescox_output_inelastic_cross_sections()
            f_l.append(exp_output)

        return np.array(f_l), angles_output


